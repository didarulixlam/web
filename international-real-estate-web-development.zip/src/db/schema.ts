import {
  pgTable,
  serial,
  text,
  integer,
  numeric,
  boolean,
  timestamp,
  jsonb,
  varchar,
} from "drizzle-orm/pg-core";

// ── Agents ──────────────────────────────────────────────────────────────────
export const agents = pgTable("agents", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 120 }).notNull(),
  title: varchar("title", { length: 120 }),
  email: varchar("email", { length: 200 }).notNull().unique(),
  phone: varchar("phone", { length: 40 }),
  photoUrl: text("photo_url"),
  bio: text("bio"),
  languages: text("languages").array(),
  rating: numeric("rating", { precision: 3, scale: 1 }),
  dealsClosed: integer("deals_closed").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

// ── Properties ───────────────────────────────────────────────────────────────
export const properties = pgTable("properties", {
  id: serial("id").primaryKey(),
  slug: varchar("slug", { length: 200 }).notNull().unique(),
  title: varchar("title", { length: 300 }).notNull(),
  description: text("description"),
  type: varchar("type", { length: 60 }).notNull(), // apartment | villa | commercial | land | duplex
  status: varchar("status", { length: 40 }).notNull().default("available"), // available | sold | rented
  listingType: varchar("listing_type", { length: 20 }).notNull().default("sale"), // sale | rent
  priceUSD: numeric("price_usd", { precision: 14, scale: 2 }).notNull(),
  priceBDT: numeric("price_bdt", { precision: 18, scale: 2 }),
  currency: varchar("currency", { length: 10 }).default("USD"),
  areaSqft: integer("area_sqft"),
  bedrooms: integer("bedrooms"),
  bathrooms: integer("bathrooms"),
  floors: integer("floors"),
  parking: boolean("parking").default(false),
  furnished: boolean("furnished").default(false),
  yearBuilt: integer("year_built"),
  city: varchar("city", { length: 120 }),
  district: varchar("district", { length: 120 }),
  address: text("address"),
  latitude: numeric("latitude", { precision: 10, scale: 6 }),
  longitude: numeric("longitude", { precision: 10, scale: 6 }),
  images: text("images").array(),
  amenities: text("amenities").array(),
  features: jsonb("features"), // { key: value }
  agentId: integer("agent_id").references(() => agents.id),
  featured: boolean("featured").default(false),
  views: integer("views").default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// ── Leads ────────────────────────────────────────────────────────────────────
export const leads = pgTable("leads", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 120 }).notNull(),
  email: varchar("email", { length: 200 }).notNull(),
  phone: varchar("phone", { length: 40 }),
  message: text("message"),
  propertyId: integer("property_id").references(() => properties.id),
  agentId: integer("agent_id").references(() => agents.id),
  source: varchar("source", { length: 60 }).default("website"),
  gdprConsent: boolean("gdpr_consent").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// ── Testimonials ─────────────────────────────────────────────────────────────
export const testimonials = pgTable("testimonials", {
  id: serial("id").primaryKey(),
  clientName: varchar("client_name", { length: 120 }).notNull(),
  clientTitle: varchar("client_title", { length: 120 }),
  clientPhoto: text("client_photo"),
  quote: text("quote").notNull(),
  rating: integer("rating").default(5),
  featured: boolean("featured").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});
