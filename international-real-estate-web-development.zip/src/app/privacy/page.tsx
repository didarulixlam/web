import { ClientLayout } from "@/components/ClientLayout";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Privacy Policy",
  description: "RDAL's privacy policy — how we collect, use, and protect your personal data.",
};

export default function PrivacyPage() {
  return (
    <ClientLayout>
      <div className="min-h-screen pt-28 pb-20">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-3xl font-bold text-white mb-2">Privacy Policy</h1>
          <p className="text-white/40 text-sm mb-10">Last updated: January 2025</p>

          <div className="space-y-8 text-white/70 text-sm leading-relaxed">
            {[
              { title: "1. Who We Are", content: "Rangpur Architectural Design Ltd. (RDAL), registered in Bangladesh, is the data controller for personal information collected through this website (rdal.com.bd)." },
              { title: "2. What Data We Collect", content: "We collect: (a) Contact information you provide — name, email, phone — when submitting enquiries or subscribing to newsletters. (b) Usage data — pages visited, time on site, device type — collected anonymously via analytics. (c) Cookies — session cookies for site functionality and optional analytics cookies." },
              { title: "3. Legal Basis (GDPR & Bangladesh Data Protection)", content: "We process your data based on: (a) Consent — you explicitly tick the consent checkbox before submitting forms. (b) Legitimate interest — to respond to your enquiries and improve our service. You may withdraw consent at any time by emailing privacy@rdal.com.bd." },
              { title: "4. How We Use Your Data", content: "Your data is used to: respond to property enquiries, send you relevant property updates (if subscribed), improve our website and services, and comply with legal obligations. We do NOT sell or share your data with third parties for marketing purposes." },
              { title: "5. Data Retention", content: "Enquiry data is retained for 24 months from collection. Newsletter subscriptions are retained until you unsubscribe. You may request deletion at any time." },
              { title: "6. Your Rights", content: "Under GDPR and equivalent laws, you have rights to: access your data, correct inaccuracies, request deletion ('right to be forgotten'), restrict or object to processing, and data portability. Exercise these rights by emailing privacy@rdal.com.bd." },
              { title: "7. Cookies", content: "We use essential cookies (required for site function) and optional analytics cookies. You may decline analytics cookies via your browser settings. We do not use advertising cookies." },
              { title: "8. Security", content: "All data is transmitted via HTTPS/TLS encryption. We maintain organisational and technical safeguards to protect your information from unauthorised access." },
              { title: "9. Contact", content: "For privacy queries or to exercise your rights: privacy@rdal.com.bd | RDAL, Munshipara, Rangpur, Bangladesh." },
            ].map((section) => (
              <section key={section.title}>
                <h2 className="text-white font-bold text-base mb-2">{section.title}</h2>
                <p>{section.content}</p>
              </section>
            ))}
          </div>
        </div>
      </div>
    </ClientLayout>
  );
}
