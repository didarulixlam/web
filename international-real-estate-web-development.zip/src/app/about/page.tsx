import { ClientLayout } from "@/components/ClientLayout";
import { GradientOrbs, ScrollReveal } from "@/components/AnimatedBackground";
import { CheckCircle, Award, Users, Building2, TrendingUp, Heart } from "lucide-react";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "About RDAL",
  description: "Learn about Rangpur Architectural Design Ltd — Bangladesh's premier real estate developer since 2010.",
};

const MILESTONES = [
  { year: "2010", title: "Company Founded", desc: "RDAL established in Rangpur with a vision to transform Bangladesh's real estate landscape." },
  { year: "2013", title: "First Major Project", desc: "Completed our first multi-storey residential complex — setting the benchmark for quality." },
  { year: "2016", title: "Dhaka Expansion", desc: "Opened Dhaka office and launched premium apartment developments in Gulshan & Banani." },
  { year: "2019", title: "NRB Investment Desk", desc: "Launched dedicated services for Non-Resident Bangladeshi investors worldwide." },
  { year: "2022", title: "500 Projects Milestone", desc: "Celebrated 500 successfully delivered projects across 6 major cities." },
  { year: "2024", title: "International Recognition", desc: "Awarded Best Real Estate Developer – Bangladesh at Asia Pacific Property Awards." },
];

const VALUES = [
  { icon: "🏗️", title: "Quality First", desc: "Every project meets international construction standards with RAJUK compliance." },
  { icon: "⏰", title: "On-Time Delivery", desc: "We guarantee handover on schedule — in writing. No excuses, no delays." },
  { icon: "🤝", title: "Transparency", desc: "Clear pricing, honest communication, and zero hidden fees throughout." },
  { icon: "🌱", title: "Sustainability", desc: "Green building practices and energy-efficient design in every new project." },
  { icon: "❤️", title: "Community", desc: "Building not just buildings, but thriving communities with lasting value." },
  { icon: "🌍", title: "Global Reach", desc: "Serving clients from Bangladesh, UK, USA, Middle East, and beyond." },
];

export default function AboutPage() {
  return (
    <ClientLayout>
      <div className="min-h-screen pt-20">
        {/* Hero */}
        <section className="relative py-24 overflow-hidden border-b border-white/5">
          <GradientOrbs />
          <div className="absolute inset-0 opacity-20">
            <img
              src="https://images.pexels.com/photos/13525370/pexels-photo-13525370.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=1600"
              alt=""
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-slate-950/80" />
          </div>
          <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <span className="text-amber-400 text-sm font-semibold uppercase tracking-widest block mb-3">Our Story</span>
            <h1 className="text-4xl sm:text-6xl font-bold text-white mb-6">
              Building Bangladesh&apos;s Future,<br />
              <span className="gradient-text">One Dream at a Time</span>
            </h1>
            <p className="text-white/60 text-lg max-w-2xl mx-auto leading-relaxed">
              Since 2010, Rangpur Architectural Design Ltd. has delivered over 500 premium properties
              to families and investors across Bangladesh and the global NRB community.
            </p>
          </div>
        </section>

        {/* Mission & Vision */}
        <section className="py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid lg:grid-cols-2 gap-16 items-center">
              <ScrollReveal>
                <img
                  src="https://images.pexels.com/photos/18340726/pexels-photo-18340726.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=800"
                  alt="RDAL building project"
                  className="rounded-3xl w-full h-80 object-cover"
                />
              </ScrollReveal>
              <ScrollReveal delay={0.2}>
                <span className="text-amber-400 text-sm font-semibold uppercase tracking-widest block mb-3">Who We Are</span>
                <h2 className="text-3xl font-bold text-white mb-6">
                  Bangladesh&apos;s Most Trusted Real Estate Developer
                </h2>
                <p className="text-white/60 leading-relaxed mb-6">
                  Rangpur Architectural Design Ltd. (RDAL) was founded with a simple but powerful mission:
                  to make quality housing accessible to every Bangladeshi family, whether they live locally
                  or abroad. We combine award-winning architecture with rigorous construction standards to
                  deliver homes that stand the test of time.
                </p>
                <p className="text-white/60 leading-relaxed mb-8">
                  Our team of 200+ professionals — architects, engineers, property consultants, and legal
                  experts — work together to ensure every project exceeds expectations.
                </p>
                <div className="grid grid-cols-2 gap-4">
                  {[
                    { icon: Building2, value: "500+", label: "Projects Completed" },
                    { icon: Users, value: "2,400+", label: "Happy Families" },
                    { icon: TrendingUp, value: "12+", label: "Years Experience" },
                    { icon: Award, value: "18", label: "Industry Awards" },
                  ].map(({ icon: Icon, value, label }) => (
                    <div key={label} className="bg-slate-900 rounded-xl p-4 border border-white/5">
                      <Icon className="w-5 h-5 text-amber-400 mb-2" />
                      <div className="text-white font-bold text-2xl">{value}</div>
                      <div className="text-white/40 text-xs">{label}</div>
                    </div>
                  ))}
                </div>
              </ScrollReveal>
            </div>
          </div>
        </section>

        {/* Values */}
        <section className="py-20 bg-slate-900/50 border-y border-white/5">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <ScrollReveal className="text-center mb-14">
              <span className="text-amber-400 text-sm font-semibold uppercase tracking-widest block mb-2">Our DNA</span>
              <h2 className="text-3xl sm:text-4xl font-bold text-white">Core Values</h2>
            </ScrollReveal>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {VALUES.map((v, i) => (
                <ScrollReveal key={v.title} delay={i * 0.08}>
                  <div className="p-6 bg-slate-900 rounded-2xl border border-white/5 hover:border-amber-500/20 transition-all hover:-translate-y-1">
                    <div className="text-4xl mb-3">{v.icon}</div>
                    <h3 className="text-white font-bold text-lg mb-2">{v.title}</h3>
                    <p className="text-white/50 text-sm leading-relaxed">{v.desc}</p>
                  </div>
                </ScrollReveal>
              ))}
            </div>
          </div>
        </section>

        {/* Timeline */}
        <section className="py-20">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <ScrollReveal className="text-center mb-14">
              <span className="text-amber-400 text-sm font-semibold uppercase tracking-widest block mb-2">Our Journey</span>
              <h2 className="text-3xl sm:text-4xl font-bold text-white">Milestones That Matter</h2>
            </ScrollReveal>
            <div className="relative">
              <div className="absolute left-1/2 top-0 bottom-0 w-px bg-white/10 -translate-x-1/2 hidden sm:block" />
              {MILESTONES.map((m, i) => (
                <ScrollReveal key={m.year} delay={i * 0.1}>
                  <div className={`relative flex items-center gap-8 mb-10 ${i % 2 === 0 ? "sm:flex-row" : "sm:flex-row-reverse"}`}>
                    <div className="flex-1 hidden sm:block" />
                    <div className="absolute left-1/2 -translate-x-1/2 w-4 h-4 bg-amber-500 rounded-full border-4 border-slate-950 hidden sm:block" />
                    <div className="flex-1 bg-slate-900 rounded-2xl p-6 border border-white/5 hover:border-amber-500/20 transition-all">
                      <span className="text-amber-400 font-bold text-sm">{m.year}</span>
                      <h3 className="text-white font-bold mt-1 mb-2">{m.title}</h3>
                      <p className="text-white/50 text-sm leading-relaxed">{m.desc}</p>
                    </div>
                  </div>
                </ScrollReveal>
              ))}
            </div>
          </div>
        </section>

        {/* Certifications */}
        <section className="py-16 bg-slate-900/50 border-y border-white/5">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <ScrollReveal className="text-center mb-10">
              <h2 className="text-2xl font-bold text-white">Accreditations & Compliance</h2>
            </ScrollReveal>
            <div className="flex flex-wrap justify-center gap-4">
              {[
                "RAJUK Approved",
                "ISO 9001:2015",
                "BGMEA Partner",
                "REHAB Member",
                "Bangladesh Real Estate Society",
                "Asia Pacific Property Awards",
              ].map((badge) => (
                <div key={badge} className="flex items-center gap-2 px-5 py-3 bg-slate-900 border border-white/10 rounded-xl text-white/70 text-sm">
                  <CheckCircle className="w-4 h-4 text-amber-400" />
                  {badge}
                </div>
              ))}
            </div>
          </div>
        </section>
      </div>
    </ClientLayout>
  );
}
