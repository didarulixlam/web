import { ClientLayout } from "@/components/ClientLayout";
import { HomePage } from "@/components/HomePage";

export default function Page() {
  return (
    <ClientLayout>
      <HomePage />
    </ClientLayout>
  );
}
