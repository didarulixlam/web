import { ClientLayout } from "@/components/ClientLayout";
import Link from "next/link";
import { PROPERTIES } from "@/lib/mock-data";
import type { Metadata } from "next";

export const metadata: Metadata = { title: "Sitemap" };

export default function SitemapPage() {
  const sections = [
    {
      title: "Main Pages",
      links: [
        { label: "Home", href: "/" },
        { label: "About RDAL", href: "/about" },
        { label: "Our Services", href: "/services" },
        { label: "Contact Us", href: "/contact" },
      ],
    },
    {
      title: "Properties",
      links: [
        { label: "All Properties", href: "/properties" },
        ...PROPERTIES.map((p) => ({ label: p.title, href: `/properties/${p.slug}` })),
      ],
    },
    {
      title: "Community",
      links: [
        { label: "Our Agents", href: "/agents" },
        { label: "Client Testimonials", href: "/testimonials" },
      ],
    },
    {
      title: "Legal",
      links: [
        { label: "Privacy Policy", href: "/privacy" },
        { label: "Terms of Service", href: "/terms" },
      ],
    },
  ];

  return (
    <ClientLayout>
      <div className="min-h-screen pt-28 pb-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-3xl font-bold text-white mb-10">Sitemap</h1>
          <div className="grid sm:grid-cols-2 gap-10">
            {sections.map((section) => (
              <div key={section.title}>
                <h2 className="text-amber-400 font-semibold text-sm uppercase tracking-widest mb-4">
                  {section.title}
                </h2>
                <ul className="space-y-2">
                  {section.links.map(({ label, href }) => (
                    <li key={href}>
                      <Link
                        href={href}
                        className="text-white/60 hover:text-amber-400 transition-colors text-sm"
                      >
                        {label}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </div>
    </ClientLayout>
  );
}
