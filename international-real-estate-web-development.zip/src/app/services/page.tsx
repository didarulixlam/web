import { ClientLayout } from "@/components/ClientLayout";
import { SERVICES } from "@/lib/mock-data";
import { GradientOrbs, ScrollReveal } from "@/components/AnimatedBackground";
import { ArrowRight, CheckCircle } from "lucide-react";
import Link from "next/link";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Our Services",
  description: "RDAL offers comprehensive real estate services — property development, residential sales, commercial leasing, NRB investment guidance, and more.",
};

const DETAILED_SERVICES = [
  {
    emoji: "🏗️",
    title: "Property Development",
    description: "From land acquisition to final handover, we manage the entire development lifecycle. Our RAJUK-licensed architects and engineers ensure structural integrity, modern design, and timely delivery.",
    features: ["Land acquisition & site assessment", "RAJUK plan approval", "Licensed architect & engineering", "Quality material sourcing", "Structural warranties", "Post-handover maintenance"],
    image: "https://images.pexels.com/photos/18340726/pexels-photo-18340726.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=400&w=600",
  },
  {
    emoji: "🏡",
    title: "Residential Sales",
    description: "Our residential portfolio spans 2BHK apartments to 5-bedroom luxury villas across Rangpur, Dhaka, Chittagong, Rajshahi, and Sylhet — each with full legal documentation.",
    features: ["Curated apartment listings", "Villa & duplex sales", "Easy installment plans", "Title deed verification", "Registry & mutation support", "12-month price lock guarantee"],
    image: "https://images.pexels.com/photos/37500649/pexels-photo-37500649.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=400&w=600",
  },
  {
    emoji: "🏢",
    title: "Commercial Leasing",
    description: "Retail showrooms, corporate offices, hospitality spaces — we match businesses with commercial properties that drive growth and visibility.",
    features: ["Retail & showroom spaces", "Corporate office suites", "Restaurant & hospitality units", "Flexible lease terms", "CAM (Common Area Maintenance)", "Signage & branding rights"],
    image: "https://images.pexels.com/photos/13525370/pexels-photo-13525370.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=400&w=600",
  },
  {
    emoji: "🌍",
    title: "NRB Investment Services",
    description: "Our dedicated NRB desk guides Non-Resident Bangladeshis through every step of investing from abroad — with multi-currency transactions, PoA support, and legal safeguards.",
    features: ["Multi-currency transactions (USD, GBP, EUR, AED)", "Power of Attorney facilitation", "Remittance guidance (BEFTN)", "Remote property viewing (video tours)", "Foreign investment compliance", "Bangladesh Bank regulations support"],
    image: "https://images.pexels.com/photos/11596373/pexels-photo-11596373.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=400&w=600",
  },
  {
    emoji: "📐",
    title: "Architecture & Interior Design",
    description: "Our in-house design studio creates spaces that are both beautiful and functional — blending Bangladeshi cultural heritage with global contemporary aesthetics.",
    features: ["Architectural blueprint design", "Interior design packages", "3D visualization & walkthroughs", "Sustainable green design", "Custom modification requests", "Landscape & outdoor design"],
    image: "https://images.pexels.com/photos/6957083/pexels-photo-6957083.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=400&w=600",
  },
  {
    emoji: "⚖️",
    title: "Legal & Documentation",
    description: "Our in-house legal team handles all property-related documentation — from title verification to registry — ensuring complete compliance with Bangladesh property law.",
    features: ["Title deed verification", "Mutation & registry", "RAJUK NOC processing", "Sale agreement drafting", "Property tax compliance", "Power of Attorney notarization"],
    image: "https://images.pexels.com/photos/36394653/pexels-photo-36394653.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=400&w=600",
  },
];

export default function ServicesPage() {
  return (
    <ClientLayout>
      <div className="min-h-screen pt-20">
        {/* Hero */}
        <section className="relative py-20 overflow-hidden border-b border-white/5">
          <GradientOrbs />
          <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <span className="text-amber-400 text-sm font-semibold uppercase tracking-widest block mb-3">What We Do</span>
            <h1 className="text-4xl sm:text-5xl font-bold text-white mb-4">Comprehensive Real Estate Services</h1>
            <p className="text-white/50 text-lg max-w-xl mx-auto leading-relaxed">
              End-to-end real estate expertise — from land to livable space, from investment to legal clarity.
            </p>
          </div>
        </section>

        {/* Services Grid (Quick Cards) */}
        <section className="py-16 border-b border-white/5">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
              {SERVICES.map((s, i) => (
                <ScrollReveal key={s.title} delay={i * 0.06}>
                  <div className="text-center p-4 bg-slate-900 rounded-2xl border border-white/5 hover:border-amber-500/20 transition-all hover:-translate-y-1">
                    <div className="text-3xl mb-2">{s.icon}</div>
                    <div className="text-white text-xs font-semibold leading-tight">{s.title}</div>
                  </div>
                </ScrollReveal>
              ))}
            </div>
          </div>
        </section>

        {/* Detailed Service Sections */}
        <section className="py-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-20">
            {DETAILED_SERVICES.map((svc, i) => (
              <ScrollReveal key={svc.title} delay={0.1}>
                <div className={`grid lg:grid-cols-2 gap-12 items-center ${i % 2 !== 0 ? "lg:flex-row-reverse" : ""}`}>
                  <div className={i % 2 !== 0 ? "lg:order-2" : ""}>
                    <div className="text-4xl mb-4">{svc.emoji}</div>
                    <h2 className="text-2xl sm:text-3xl font-bold text-white mb-4">{svc.title}</h2>
                    <p className="text-white/60 leading-relaxed mb-6">{svc.description}</p>
                    <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 mb-6">
                      {svc.features.map((f) => (
                        <li key={f} className="flex items-start gap-2 text-white/70 text-sm">
                          <CheckCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                          {f}
                        </li>
                      ))}
                    </ul>
                    <Link
                      href="/contact"
                      className="inline-flex items-center gap-2 px-6 py-3 bg-amber-500 hover:bg-amber-400 text-slate-900 font-bold rounded-xl transition-all text-sm"
                    >
                      Get a Free Consultation
                      <ArrowRight className="w-4 h-4" />
                    </Link>
                  </div>
                  <div className={i % 2 !== 0 ? "lg:order-1" : ""}>
                    <img
                      src={svc.image}
                      alt={svc.title}
                      className="w-full h-72 object-cover rounded-3xl"
                      loading="lazy"
                    />
                  </div>
                </div>
              </ScrollReveal>
            ))}
          </div>
        </section>

        {/* CTA */}
        <section className="py-20 bg-slate-900/50 border-t border-white/5">
          <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-3xl font-bold text-white mb-4">Not Sure Where to Start?</h2>
            <p className="text-white/50 mb-8">
              Our expert consultants offer a free 30-minute property consultation — no obligation.
            </p>
            <Link
              href="/contact"
              className="inline-flex items-center gap-2 px-8 py-4 bg-amber-500 hover:bg-amber-400 text-slate-900 font-bold rounded-2xl text-base transition-all shadow-lg shadow-amber-500/20"
            >
              Book Free Consultation
              <ArrowRight className="w-5 h-5" />
            </Link>
          </div>
        </section>
      </div>
    </ClientLayout>
  );
}
