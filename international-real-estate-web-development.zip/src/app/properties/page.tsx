import { ClientLayout } from "@/components/ClientLayout";
import { PropertiesPage } from "@/components/PropertiesPage";

export const metadata = {
  title: "Browse Properties",
  description: "Search and filter premium properties across Bangladesh. Apartments, villas, commercial spaces and land plots.",
};

export default function Page() {
  return (
    <ClientLayout>
      <PropertiesPage />
    </ClientLayout>
  );
}
