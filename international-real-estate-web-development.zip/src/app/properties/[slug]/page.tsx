import { ClientLayout } from "@/components/ClientLayout";
import { PropertyDetailPage } from "@/components/PropertyDetailPage";
import { PROPERTIES } from "@/lib/mock-data";
import { notFound } from "next/navigation";
import type { Metadata } from "next";

export async function generateStaticParams() {
  return PROPERTIES.map((p) => ({ slug: p.slug }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const property = PROPERTIES.find((p) => p.slug === slug);
  if (!property) return { title: "Property Not Found" };
  return {
    title: property.title,
    description: property.description.slice(0, 160),
    openGraph: {
      images: [{ url: property.images[0] ?? "" }],
    },
  };
}

export default async function Page({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const property = PROPERTIES.find((p) => p.slug === slug);
  if (!property) notFound();

  return (
    <ClientLayout>
      <PropertyDetailPage property={property} />
    </ClientLayout>
  );
}
