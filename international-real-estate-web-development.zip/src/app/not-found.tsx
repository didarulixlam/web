import Link from "next/link";
import { ClientLayout } from "@/components/ClientLayout";
import { GradientOrbs } from "@/components/AnimatedBackground";

export default function NotFound() {
  return (
    <ClientLayout>
      <div className="min-h-screen flex items-center justify-center relative">
        <GradientOrbs />
        <div className="relative text-center px-4">
          <div className="text-[120px] font-bold text-white/5 leading-none select-none">404</div>
          <div className="-mt-8 mb-6">
            <h1 className="text-3xl font-bold text-white mb-3">Page Not Found</h1>
            <p className="text-white/50 max-w-md mx-auto">
              The page you&apos;re looking for doesn&apos;t exist or has been moved.
            </p>
          </div>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Link
              href="/"
              className="px-6 py-3 bg-amber-500 hover:bg-amber-400 text-slate-900 font-bold rounded-xl transition-all"
            >
              Go Home
            </Link>
            <Link
              href="/properties"
              className="px-6 py-3 border border-amber-500/30 text-amber-400 hover:bg-amber-500/10 font-semibold rounded-xl transition-all"
            >
              Browse Properties
            </Link>
          </div>
        </div>
      </div>
    </ClientLayout>
  );
}
