import { ClientLayout } from "@/components/ClientLayout";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Terms of Service",
  description: "RDAL's terms of service for using our website and real estate services.",
};

export default function TermsPage() {
  return (
    <ClientLayout>
      <div className="min-h-screen pt-28 pb-20">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-3xl font-bold text-white mb-2">Terms of Service</h1>
          <p className="text-white/40 text-sm mb-10">Last updated: January 2025</p>

          <div className="space-y-8 text-white/70 text-sm leading-relaxed">
            {[
              { title: "1. Acceptance", content: "By accessing rdal.com.bd, you agree to these Terms of Service. If you do not agree, please do not use this website." },
              { title: "2. Information Accuracy", content: "All property listings, prices, and availability are provided in good faith but are subject to change without notice. Always verify details with our agents before making any decisions." },
              { title: "3. Property Enquiries", content: "Submitting an enquiry form does not constitute a reservation or booking. No legal obligation arises until a formal sale agreement or lease agreement is signed by both parties." },
              { title: "4. Intellectual Property", content: "All content on this site — including photographs, text, designs, and logos — is the property of RDAL or its licensors and may not be reproduced without written permission." },
              { title: "5. Limitation of Liability", content: "RDAL shall not be liable for any indirect, incidental, or consequential damages arising from use of this website or reliance on information herein." },
              { title: "6. Governing Law", content: "These terms are governed by the laws of the People's Republic of Bangladesh. Disputes shall be resolved in the courts of Rangpur, Bangladesh." },
              { title: "7. Changes", content: "RDAL may update these terms at any time. Continued use of the website after changes constitutes acceptance." },
              { title: "8. Contact", content: "Legal queries: legal@rdal.com.bd | RDAL, Munshipara, Rangpur, Bangladesh." },
            ].map((section) => (
              <section key={section.title}>
                <h2 className="text-white font-bold text-base mb-2">{section.title}</h2>
                <p>{section.content}</p>
              </section>
            ))}
          </div>
        </div>
      </div>
    </ClientLayout>
  );
}
