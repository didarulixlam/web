import { ClientLayout } from "@/components/ClientLayout";
import { AgentCard } from "@/components/AgentCard";
import { AGENTS } from "@/lib/mock-data";
import { GradientOrbs, ScrollReveal } from "@/components/AnimatedBackground";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Our Agents",
  description: "Meet RDAL's expert property consultants — multi-lingual professionals ready to help you buy, sell or invest.",
};

export default function AgentsPage() {
  return (
    <ClientLayout>
      <div className="min-h-screen pt-20">
        {/* Hero */}
        <section className="relative py-20 overflow-hidden border-b border-white/5">
          <GradientOrbs />
          <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <span className="text-amber-400 text-sm font-semibold uppercase tracking-widest block mb-3">The Team</span>
            <h1 className="text-4xl sm:text-5xl font-bold text-white mb-4">Meet Our Expert Agents</h1>
            <p className="text-white/50 text-lg max-w-xl mx-auto">
              Multi-lingual professionals with deep market knowledge — committed to finding you the perfect property.
            </p>
          </div>
        </section>

        {/* Agents Grid */}
        <section className="py-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {AGENTS.map((agent, i) => (
                <ScrollReveal key={agent.id} delay={i * 0.1}>
                  <AgentCard agent={agent} />
                </ScrollReveal>
              ))}
            </div>

            {/* Join Team CTA */}
            <ScrollReveal delay={0.2} className="mt-16 text-center p-12 bg-slate-900 rounded-3xl border border-white/5">
              <h2 className="text-2xl font-bold text-white mb-4">Join Our Growing Team</h2>
              <p className="text-white/50 mb-6 max-w-lg mx-auto text-sm leading-relaxed">
                Are you a real estate professional passionate about connecting clients with their dream properties?
                RDAL offers competitive commissions, comprehensive training, and a collaborative culture.
              </p>
              <a
                href="mailto:careers@rdal.com.bd"
                className="inline-flex items-center gap-2 px-8 py-3 bg-amber-500 hover:bg-amber-400 text-slate-900 font-bold rounded-xl transition-all shadow-lg shadow-amber-500/20"
              >
                Apply Now
              </a>
            </ScrollReveal>
          </div>
        </section>
      </div>
    </ClientLayout>
  );
}
