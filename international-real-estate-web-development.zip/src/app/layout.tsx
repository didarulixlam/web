import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: {
    default: "RDAL – Rangpur Architectural Design Ltd. | Premium Real Estate Bangladesh",
    template: "%s | RDAL Real Estate",
  },
  description:
    "Bangladesh's premier real estate developer. Browse luxury apartments, villas, commercial spaces and land across Rangpur, Dhaka, Chittagong and beyond.",
  keywords: ["real estate Bangladesh", "property Rangpur", "apartments Dhaka", "luxury villa Bangladesh", "RDAL"],
  authors: [{ name: "Rangpur Architectural Design Ltd." }],
  openGraph: {
    type: "website",
    locale: "en_US",
    url: "https://rdal.com.bd",
    siteName: "RDAL Real Estate",
    title: "RDAL – Premium Real Estate Bangladesh",
    description: "Discover premium properties across Bangladesh with RDAL.",
    images: [
      {
        url: "https://images.pexels.com/photos/11596373/pexels-photo-11596373.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200",
        width: 1200,
        height: 630,
        alt: "RDAL Real Estate Bangladesh",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "RDAL – Premium Real Estate Bangladesh",
    description: "Discover premium properties across Bangladesh with RDAL.",
  },
  robots: { index: true, follow: true },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="scroll-smooth">
      <body className="min-h-screen bg-[#020817] antialiased">
        {children}
      </body>
    </html>
  );
}
