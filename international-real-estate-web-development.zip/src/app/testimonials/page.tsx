import { ClientLayout } from "@/components/ClientLayout";
import { TESTIMONIALS } from "@/lib/mock-data";
import { GradientOrbs, ScrollReveal } from "@/components/AnimatedBackground";
import { Star, Quote } from "lucide-react";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Client Testimonials",
  description: "Read what our clients say about RDAL's real estate services — trusted by 2,400+ families across Bangladesh and the globe.",
};

export default function TestimonialsPage() {
  return (
    <ClientLayout>
      <div className="min-h-screen pt-20">
        {/* Hero */}
        <section className="relative py-20 overflow-hidden border-b border-white/5">
          <GradientOrbs />
          <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <span className="text-amber-400 text-sm font-semibold uppercase tracking-widest block mb-3">Social Proof</span>
            <h1 className="text-4xl sm:text-5xl font-bold text-white mb-4">What Our Clients Say</h1>
            <p className="text-white/50 text-lg max-w-xl mx-auto">
              Real stories from real clients — discover why 2,400+ families chose RDAL to build their dreams.
            </p>

            {/* Rating Summary */}
            <div className="flex items-center justify-center gap-3 mt-8 p-4 bg-slate-900 border border-white/5 rounded-2xl inline-flex mx-auto">
              <div className="flex gap-1">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 text-amber-400 fill-amber-400" />
                ))}
              </div>
              <span className="text-white font-bold text-xl">4.9</span>
              <span className="text-white/40 text-sm">/ 5.0 based on 2,400+ reviews</span>
            </div>
          </div>
        </section>

        {/* Testimonials Grid */}
        <section className="py-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {[...TESTIMONIALS, ...TESTIMONIALS].map((t, i) => (
                <ScrollReveal key={`${t.id}-${i}`} delay={(i % 4) * 0.1}>
                  <article className="bg-slate-900 rounded-2xl border border-white/5 hover:border-amber-500/20 transition-all p-6 hover:-translate-y-1 hover:shadow-xl hover:shadow-amber-500/5">
                    <Quote className="w-8 h-8 text-amber-500/30 mb-4" />
                    <p className="text-white/70 leading-relaxed mb-6 italic">
                      &ldquo;{t.quote}&rdquo;
                    </p>
                    <div className="flex items-center gap-4 pt-4 border-t border-white/5">
                      <img
                        src={t.clientPhoto}
                        alt={t.clientName}
                        className="w-12 h-12 rounded-full object-cover border-2 border-amber-500/20"
                        loading="lazy"
                      />
                      <div>
                        <div className="text-white font-bold text-sm">{t.clientName}</div>
                        <div className="text-white/40 text-xs">{t.clientTitle}</div>
                      </div>
                      <div className="ml-auto flex gap-0.5">
                        {[...Array(t.rating)].map((_, ri) => (
                          <Star key={ri} className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                        ))}
                      </div>
                    </div>
                  </article>
                </ScrollReveal>
              ))}
            </div>

            {/* Add Your Review */}
            <ScrollReveal delay={0.2} className="mt-16 text-center p-12 bg-slate-900 rounded-3xl border border-white/5">
              <h2 className="text-2xl font-bold text-white mb-4">Have a Story to Share?</h2>
              <p className="text-white/50 mb-6 max-w-lg mx-auto text-sm leading-relaxed">
                If you&apos;ve bought, rented or invested through RDAL, we&apos;d love to hear your story.
                Your feedback helps other families make confident decisions.
              </p>
              <a
                href="mailto:feedback@rdal.com.bd"
                className="inline-flex items-center gap-2 px-8 py-3 bg-amber-500 hover:bg-amber-400 text-slate-900 font-bold rounded-xl transition-all shadow-lg shadow-amber-500/20 text-sm"
              >
                Submit Your Review
              </a>
            </ScrollReveal>
          </div>
        </section>
      </div>
    </ClientLayout>
  );
}
