import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { leads } from "@/db/schema";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { name, email, phone, message, propertyId, agentId, gdprConsent } = body;

    // Server-side validation
    if (!name || typeof name !== "string" || name.trim().length < 2) {
      return NextResponse.json({ message: "Invalid name" }, { status: 400 });
    }
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return NextResponse.json({ message: "Invalid email" }, { status: 400 });
    }
    if (!message || typeof message !== "string" || message.trim().length < 10) {
      return NextResponse.json({ message: "Message too short" }, { status: 400 });
    }
    if (!gdprConsent) {
      return NextResponse.json({ message: "GDPR consent required" }, { status: 400 });
    }

    await db.insert(leads).values({
      name: name.trim(),
      email: email.trim().toLowerCase(),
      phone: phone?.trim() ?? null,
      message: message.trim(),
      propertyId: propertyId ? parseInt(propertyId, 10) : null,
      agentId: agentId ? parseInt(agentId, 10) : null,
      gdprConsent: true,
      source: "website",
    });

    return NextResponse.json({ success: true }, { status: 201 });
  } catch (err) {
    console.error("[leads POST]", err);
    return NextResponse.json({ message: "Internal server error" }, { status: 500 });
  }
}

export async function GET() {
  try {
    const allLeads = await db.select().from(leads).limit(100);
    return NextResponse.json(allLeads);
  } catch (err) {
    console.error("[leads GET]", err);
    return NextResponse.json({ message: "Internal server error" }, { status: 500 });
  }
}
