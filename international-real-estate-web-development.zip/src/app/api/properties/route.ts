import { NextRequest, NextResponse } from "next/server";
import { PROPERTIES } from "@/lib/mock-data";

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);

  const query = searchParams.get("query")?.toLowerCase() ?? "";
  const type = searchParams.get("type") ?? "";
  const listingType = searchParams.get("listingType") ?? "";
  const city = searchParams.get("city") ?? "";
  const minPrice = parseFloat(searchParams.get("minPrice") ?? "0") || 0;
  const maxPrice = parseFloat(searchParams.get("maxPrice") ?? "0") || Infinity;
  const minBeds = parseInt(searchParams.get("minBeds") ?? "0") || 0;
  const minBaths = parseInt(searchParams.get("minBaths") ?? "0") || 0;
  const furnished = searchParams.get("furnished") ?? "";
  const featured = searchParams.get("featured") === "true";

  let results = PROPERTIES;

  if (query) {
    results = results.filter(
      (p) =>
        p.title.toLowerCase().includes(query) ||
        p.city.toLowerCase().includes(query) ||
        p.address.toLowerCase().includes(query) ||
        p.description.toLowerCase().includes(query)
    );
  }
  if (type) results = results.filter((p) => p.type === type);
  if (listingType) results = results.filter((p) => p.listingType === listingType);
  if (city) results = results.filter((p) => p.city === city);
  if (minPrice > 0) results = results.filter((p) => p.priceUSD >= minPrice);
  if (maxPrice < Infinity) results = results.filter((p) => p.priceUSD <= maxPrice);
  if (minBeds > 0) results = results.filter((p) => p.bedrooms >= minBeds);
  if (minBaths > 0) results = results.filter((p) => p.bathrooms >= minBaths);
  if (furnished === "yes") results = results.filter((p) => p.furnished);
  if (furnished === "no") results = results.filter((p) => !p.furnished);
  if (featured) results = results.filter((p) => p.featured);

  return NextResponse.json({
    results,
    total: results.length,
  });
}
