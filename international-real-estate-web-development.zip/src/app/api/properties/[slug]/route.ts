import { NextRequest, NextResponse } from "next/server";
import { PROPERTIES } from "@/lib/mock-data";

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ slug: string }> }
) {
  const { slug } = await params;
  const property = PROPERTIES.find((p) => p.slug === slug);
  if (!property) {
    return NextResponse.json({ message: "Property not found" }, { status: 404 });
  }
  return NextResponse.json(property);
}
