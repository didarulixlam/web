import { ClientLayout } from "@/components/ClientLayout";
import { ContactForm } from "@/components/ContactForm";
import { GradientOrbs, ScrollReveal } from "@/components/AnimatedBackground";
import { MapPin, Phone, Mail, Clock, MessageSquare } from "lucide-react";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Contact Us",
  description: "Get in touch with RDAL's property consultants. We respond within 24 hours.",
};

const OFFICES = [
  {
    city: "Rangpur (HQ)",
    address: "Munshipara, Rangpur City, Rangpur Division",
    phone: "+880 1711-234567",
    email: "rangpur@rdal.com.bd",
    hours: "Sat–Thu, 9AM – 6PM",
  },
  {
    city: "Dhaka",
    address: "Road 32, Gulshan-2, Dhaka 1212",
    phone: "+880 1821-345678",
    email: "dhaka@rdal.com.bd",
    hours: "Sat–Thu, 9AM – 7PM",
  },
  {
    city: "Chittagong",
    address: "Nasirabad Housing Society, Chittagong",
    phone: "+880 1900-456789",
    email: "chittagong@rdal.com.bd",
    hours: "Sat–Thu, 9AM – 6PM",
  },
];

export default function ContactPage() {
  return (
    <ClientLayout>
      <div className="min-h-screen pt-20">
        {/* Hero */}
        <section className="relative py-20 overflow-hidden border-b border-white/5">
          <GradientOrbs />
          <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <span className="text-amber-400 text-sm font-semibold uppercase tracking-widest block mb-3">Get In Touch</span>
            <h1 className="text-4xl sm:text-5xl font-bold text-white mb-4">We&apos;re Here to Help</h1>
            <p className="text-white/50 text-lg max-w-xl mx-auto">
              Whether you&apos;re buying, investing, or just exploring — our team responds within 24 hours.
            </p>
          </div>
        </section>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="grid lg:grid-cols-3 gap-10">
            {/* Left Info */}
            <div className="lg:col-span-1 space-y-8">
              {/* Contact Methods */}
              <ScrollReveal>
                <div className="space-y-4">
                  {[
                    { icon: Phone, label: "Call Us", value: "+880 1711-234567", href: "tel:+8801711234567", sub: "Available Sat–Thu, 9AM–6PM" },
                    { icon: Mail, label: "Email Us", value: "info@rdal.com.bd", href: "mailto:info@rdal.com.bd", sub: "Response within 24 hours" },
                    { icon: MessageSquare, label: "WhatsApp", value: "+880 1711-234567", href: "https://wa.me/8801711234567", sub: "Chat with us directly" },
                    { icon: MapPin, label: "Head Office", value: "Munshipara, Rangpur", href: "https://maps.google.com/?q=Rangpur+Bangladesh", sub: "Rangpur Division, Bangladesh" },
                    { icon: Clock, label: "Office Hours", value: "Sat–Thu: 9AM–6PM", href: "#", sub: "Closed Friday & public holidays" },
                  ].map(({ icon: Icon, label, value, href, sub }) => (
                    <a
                      key={label}
                      href={href}
                      target={href.startsWith("http") ? "_blank" : undefined}
                      rel={href.startsWith("http") ? "noopener noreferrer" : undefined}
                      className="flex gap-4 p-4 bg-slate-900 rounded-2xl border border-white/5 hover:border-amber-500/20 transition-all group"
                    >
                      <div className="w-10 h-10 bg-amber-500/10 rounded-xl flex items-center justify-center shrink-0 group-hover:bg-amber-500/20 transition-colors">
                        <Icon className="w-5 h-5 text-amber-400" />
                      </div>
                      <div>
                        <div className="text-white/40 text-xs mb-0.5">{label}</div>
                        <div className="text-white font-semibold text-sm group-hover:text-amber-400 transition-colors">{value}</div>
                        <div className="text-white/30 text-xs">{sub}</div>
                      </div>
                    </a>
                  ))}
                </div>
              </ScrollReveal>

              {/* Offices */}
              <ScrollReveal delay={0.1}>
                <h2 className="text-white font-bold text-lg mb-4">Our Offices</h2>
                <div className="space-y-4">
                  {OFFICES.map((office) => (
                    <div key={office.city} className="p-4 bg-slate-900 rounded-2xl border border-white/5">
                      <h3 className="text-amber-400 font-semibold text-sm mb-2">{office.city}</h3>
                      <p className="text-white/50 text-xs mb-2 leading-relaxed">{office.address}</p>
                      <p className="text-white/40 text-xs">{office.hours}</p>
                    </div>
                  ))}
                </div>
              </ScrollReveal>
            </div>

            {/* Contact Form */}
            <div className="lg:col-span-2">
              <ScrollReveal delay={0.15}>
                <div className="bg-slate-900 rounded-3xl border border-white/5 p-8">
                  <h2 className="text-white font-bold text-2xl mb-2">Send Us a Message</h2>
                  <p className="text-white/50 text-sm mb-8">
                    Tell us what you&apos;re looking for and we&apos;ll connect you with the right consultant.
                  </p>
                  <ContactForm />
                </div>
              </ScrollReveal>
            </div>
          </div>

          {/* Map */}
          <ScrollReveal delay={0.2} className="mt-12">
            <h2 className="text-white font-bold text-2xl mb-6">Find Us</h2>
            <div className="rounded-2xl overflow-hidden border border-white/10 h-72">
              <iframe
                title="RDAL Head Office – Rangpur"
                src="https://www.openstreetmap.org/export/embed.html?bbox=89.2452%2C25.7239%2C89.2952%2C25.7639&layer=mapnik&marker=25.7439%2C89.2752"
                className="w-full h-full border-0"
                loading="lazy"
                aria-label="Map showing RDAL office in Rangpur, Bangladesh"
              />
            </div>
          </ScrollReveal>
        </div>
      </div>
    </ClientLayout>
  );
}
