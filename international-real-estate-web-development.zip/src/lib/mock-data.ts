import { BDT_PER_USD } from "./utils";

export type PropertyType = "apartment" | "villa" | "commercial" | "land" | "duplex";
export type ListingType = "sale" | "rent";
export type PropertyStatus = "available" | "sold" | "rented";

export interface Agent {
  id: number;
  name: string;
  title: string;
  email: string;
  phone: string;
  photoUrl: string;
  bio: string;
  languages: string[];
  rating: number;
  dealsClosed: number;
}

export interface Property {
  id: number;
  slug: string;
  title: string;
  description: string;
  type: PropertyType;
  status: PropertyStatus;
  listingType: ListingType;
  priceUSD: number;
  priceBDT: number;
  areaSqft: number;
  bedrooms: number;
  bathrooms: number;
  floors?: number;
  parking: boolean;
  furnished: boolean;
  yearBuilt?: number;
  city: string;
  district: string;
  address: string;
  latitude: number;
  longitude: number;
  images: string[];
  amenities: string[];
  features: Record<string, string>;
  agentId: number;
  featured: boolean;
  views: number;
}

export interface Testimonial {
  id: number;
  clientName: string;
  clientTitle: string;
  clientPhoto: string;
  quote: string;
  rating: number;
}

export const AGENTS: Agent[] = [
  {
    id: 1,
    name: "Farhan Ahmed",
    title: "Senior Property Consultant",
    email: "farhan@rdal.com.bd",
    phone: "+880 1711-234567",
    photoUrl: "https://images.pexels.com/photos/7641824/pexels-photo-7641824.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=400&w=400",
    bio: "Over 12 years of real estate experience across Rangpur, Dhaka and Chittagong markets. Specializes in luxury residential and commercial investments.",
    languages: ["Bengali", "English", "Hindi"],
    rating: 4.9,
    dealsClosed: 214,
  },
  {
    id: 2,
    name: "Nusrat Jahan",
    title: "Residential Sales Manager",
    email: "nusrat@rdal.com.bd",
    phone: "+880 1821-345678",
    photoUrl: "https://images.pexels.com/photos/7414901/pexels-photo-7414901.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=400&w=400",
    bio: "Expert in apartment and duplex sales across northern Bangladesh. Committed to transparent, client-first property transactions.",
    languages: ["Bengali", "English"],
    rating: 4.8,
    dealsClosed: 178,
  },
  {
    id: 3,
    name: "Karim Hossain",
    title: "Commercial Property Specialist",
    email: "karim@rdal.com.bd",
    phone: "+880 1900-456789",
    photoUrl: "https://images.pexels.com/photos/8292786/pexels-photo-8292786.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=400&w=400",
    bio: "15 years helping businesses find ideal commercial spaces. Deep market knowledge in Rangpur's growing commercial corridors.",
    languages: ["Bengali", "English", "Arabic"],
    rating: 4.7,
    dealsClosed: 143,
  },
  {
    id: 4,
    name: "Shaila Rahman",
    title: "International Investment Advisor",
    email: "shaila@rdal.com.bd",
    phone: "+880 1600-567890",
    photoUrl: "https://images.pexels.com/photos/12932676/pexels-photo-12932676.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=400&w=400",
    bio: "Guiding NRB (Non-Resident Bangladeshi) clients and international investors into Bangladesh's high-growth property market.",
    languages: ["Bengali", "English", "French"],
    rating: 4.9,
    dealsClosed: 96,
  },
];

export const PROPERTIES: Property[] = [
  {
    id: 1,
    slug: "alyan-dream-residency-munshipara",
    title: "Alyan Dream Residency – Munshipara",
    description: "A prestigious residential project in the heart of Munshipara, Rangpur. Featuring modern architecture, premium finishes, and world-class amenities designed for comfortable urban living. Each unit is crafted with attention to detail, maximizing natural light and ventilation.",
    type: "apartment",
    status: "available",
    listingType: "sale",
    priceUSD: 55000,
    priceBDT: 55000 * BDT_PER_USD,
    areaSqft: 1450,
    bedrooms: 3,
    bathrooms: 2,
    floors: 8,
    parking: true,
    furnished: false,
    yearBuilt: 2024,
    city: "Rangpur",
    district: "Rangpur",
    address: "Munshipara, Rangpur City, Rangpur Division, Bangladesh",
    latitude: 25.7439,
    longitude: 89.2752,
    images: [
      "https://images.pexels.com/photos/37500649/pexels-photo-37500649.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      "https://images.pexels.com/photos/6957083/pexels-photo-6957083.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      "https://images.pexels.com/photos/36710315/pexels-photo-36710315.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      "https://images.pexels.com/photos/8134753/pexels-photo-8134753.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    ],
    amenities: ["24/7 Security", "Generator Backup", "Rooftop Garden", "Gymnasium", "Prayer Room", "Intercom", "CCTV"],
    features: { "Floor Plan": "3BHK", "Facing": "South-East", "Handover": "Q2 2025", "Down Payment": "30%" },
    agentId: 1,
    featured: true,
    views: 1240,
  },
  {
    id: 2,
    slug: "skyline-heights-dhaka-gulshan",
    title: "Skyline Heights – Gulshan, Dhaka",
    description: "Ultra-premium apartment tower in Dhaka's most sought-after address. Floor-to-ceiling windows, smart home automation, and an exclusive resident sky-lounge offering panoramic city views.",
    type: "apartment",
    status: "available",
    listingType: "sale",
    priceUSD: 185000,
    priceBDT: 185000 * BDT_PER_USD,
    areaSqft: 2800,
    bedrooms: 4,
    bathrooms: 3,
    floors: 22,
    parking: true,
    furnished: true,
    yearBuilt: 2023,
    city: "Dhaka",
    district: "Dhaka",
    address: "Road 32, Gulshan-2, Dhaka 1212, Bangladesh",
    latitude: 23.7808,
    longitude: 90.4166,
    images: [
      "https://images.pexels.com/photos/11596373/pexels-photo-11596373.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      "https://images.pexels.com/photos/31817155/pexels-photo-31817155.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      "https://images.pexels.com/photos/36710315/pexels-photo-36710315.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      "https://images.pexels.com/photos/8134753/pexels-photo-8134753.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    ],
    amenities: ["Swimming Pool", "Smart Home", "Concierge", "Sky Lounge", "Helipad Access", "EV Charging", "Spa"],
    features: { "Floor Plan": "4BHK+Study", "Facing": "North", "Smart System": "Full Automation", "Handover": "Ready" },
    agentId: 4,
    featured: true,
    views: 3890,
  },
  {
    id: 3,
    slug: "green-valley-villa-chittagong",
    title: "Green Valley Villa – Nasirabad, Chittagong",
    description: "Expansive villa set on a lush 8-katha plot in the serene Nasirabad residential zone. Designed by award-winning architects with a blend of traditional Bangladeshi motifs and contemporary aesthetics.",
    type: "villa",
    status: "available",
    listingType: "sale",
    priceUSD: 320000,
    priceBDT: 320000 * BDT_PER_USD,
    areaSqft: 5200,
    bedrooms: 5,
    bathrooms: 5,
    floors: 3,
    parking: true,
    furnished: true,
    yearBuilt: 2022,
    city: "Chittagong",
    district: "Chittagong",
    address: "Nasirabad Housing Society, Chittagong, Bangladesh",
    latitude: 22.3569,
    longitude: 91.7832,
    images: [
      "https://images.pexels.com/photos/13308024/pexels-photo-13308024.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      "https://images.pexels.com/photos/6957083/pexels-photo-6957083.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      "https://images.pexels.com/photos/31817155/pexels-photo-31817155.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      "https://images.pexels.com/photos/36710315/pexels-photo-36710315.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    ],
    amenities: ["Private Pool", "Home Theater", "Servant Quarters", "Landscaped Garden", "Solar Panels", "Wine Cellar"],
    features: { "Plot Size": "8 Katha", "Style": "Colonial Modern", "Garden": "5,000 sqft", "Pool": "Yes" },
    agentId: 2,
    featured: true,
    views: 2150,
  },
  {
    id: 4,
    slug: "commerce-plaza-rangpur-city",
    title: "Commerce Plaza – Rangpur City Center",
    description: "Prime commercial space in Rangpur's bustling city center. Ideal for retail chains, banks, showrooms, and corporate offices. Excellent foot traffic and vehicle accessibility.",
    type: "commercial",
    status: "available",
    listingType: "sale",
    priceUSD: 95000,
    priceBDT: 95000 * BDT_PER_USD,
    areaSqft: 3200,
    bedrooms: 0,
    bathrooms: 4,
    floors: 5,
    parking: true,
    furnished: false,
    yearBuilt: 2023,
    city: "Rangpur",
    district: "Rangpur",
    address: "Jahaj Company More, Rangpur City, Bangladesh",
    latitude: 25.7452,
    longitude: 89.2516,
    images: [
      "https://images.pexels.com/photos/18340726/pexels-photo-18340726.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      "https://images.pexels.com/photos/13525370/pexels-photo-13525370.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      "https://images.pexels.com/photos/5674684/pexels-photo-5674684.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    ],
    amenities: ["Dedicated Parking", "Central AC", "Freight Elevator", "24/7 Security", "Backup Generator"],
    features: { "Zoning": "Commercial-A", "Floor Plate": "640 sqft each", "Loading Bay": "Yes", "Signage": "Allowed" },
    agentId: 3,
    featured: false,
    views: 870,
  },
  {
    id: 5,
    slug: "riverside-duplex-rajshahi",
    title: "Riverside Duplex – Padma Riverfront, Rajshahi",
    description: "Stunning duplex overlooking the Padma River. Modern two-floor layout with private terrace, perfect for families seeking space, privacy, and breathtaking river views.",
    type: "duplex",
    status: "available",
    listingType: "sale",
    priceUSD: 72000,
    priceBDT: 72000 * BDT_PER_USD,
    areaSqft: 2100,
    bedrooms: 4,
    bathrooms: 3,
    floors: 2,
    parking: true,
    furnished: false,
    yearBuilt: 2024,
    city: "Rajshahi",
    district: "Rajshahi",
    address: "Padma Residential Area, Rajshahi 6000, Bangladesh",
    latitude: 24.3636,
    longitude: 88.6241,
    images: [
      "https://images.pexels.com/photos/27459248/pexels-photo-27459248.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      "https://images.pexels.com/photos/6957083/pexels-photo-6957083.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      "https://images.pexels.com/photos/36710315/pexels-photo-36710315.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    ],
    amenities: ["River View Terrace", "Rooftop Deck", "Modular Kitchen", "Security System", "Garden"],
    features: { "River Frontage": "Yes", "Terrace": "800 sqft", "Style": "Contemporary", "Handover": "Q3 2025" },
    agentId: 1,
    featured: true,
    views: 1680,
  },
  {
    id: 6,
    slug: "premium-land-sylhet-beanibazar",
    title: "Premium Plot – Beanibazar, Sylhet",
    description: "5-katha registered plot in a rapidly developing zone of Sylhet's Beanibazar. Road-facing with clear title deed, suitable for residential or mixed-use development.",
    type: "land",
    status: "available",
    listingType: "sale",
    priceUSD: 28000,
    priceBDT: 28000 * BDT_PER_USD,
    areaSqft: 3600,
    bedrooms: 0,
    bathrooms: 0,
    parking: false,
    furnished: false,
    city: "Sylhet",
    district: "Sylhet",
    address: "Beanibazar, Sylhet 3120, Bangladesh",
    latitude: 24.5005,
    longitude: 92.2009,
    images: [
      "https://images.pexels.com/photos/36394653/pexels-photo-36394653.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      "https://images.pexels.com/photos/26957678/pexels-photo-26957678.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    ],
    amenities: ["Road Facing", "Utility Access", "Clear Title", "Corner Plot"],
    features: { "Land Size": "5 Katha", "Title": "Registered", "Zoning": "Residential-B", "Road Width": "20 ft" },
    agentId: 2,
    featured: false,
    views: 520,
  },
  {
    id: 7,
    slug: "executive-flat-dhaka-banani",
    title: "Executive Apartment – Banani, Dhaka",
    description: "Fully furnished executive apartment in Banani's diplomatic zone. Ideal for expats and corporate tenants. Premium finishes, 24/7 concierge, and proximity to international schools.",
    type: "apartment",
    status: "available",
    listingType: "rent",
    priceUSD: 1200,
    priceBDT: 1200 * BDT_PER_USD,
    areaSqft: 1800,
    bedrooms: 3,
    bathrooms: 2,
    floors: 12,
    parking: true,
    furnished: true,
    yearBuilt: 2020,
    city: "Dhaka",
    district: "Dhaka",
    address: "Road 11, Banani, Dhaka 1213, Bangladesh",
    latitude: 23.7937,
    longitude: 90.4066,
    images: [
      "https://images.pexels.com/photos/37224965/pexels-photo-37224965.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      "https://images.pexels.com/photos/31817155/pexels-photo-31817155.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      "https://images.pexels.com/photos/8134753/pexels-photo-8134753.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    ],
    amenities: ["Fully Furnished", "Gym", "Swimming Pool", "Concierge", "Generator", "Intercom"],
    features: { "Lease": "Min 12 months", "Pet Policy": "No Pets", "Utilities": "Included", "Parking": "Covered" },
    agentId: 4,
    featured: false,
    views: 1450,
  },
  {
    id: 8,
    slug: "garden-residency-rangpur-airport",
    title: "Garden Residency – Airport Road, Rangpur",
    description: "Thoughtfully designed apartment complex near Rangpur Airport. Perfect for professionals and growing families. Lush green surroundings with a community garden and children's play area.",
    type: "apartment",
    status: "available",
    listingType: "sale",
    priceUSD: 38000,
    priceBDT: 38000 * BDT_PER_USD,
    areaSqft: 1150,
    bedrooms: 2,
    bathrooms: 2,
    floors: 6,
    parking: false,
    furnished: false,
    yearBuilt: 2024,
    city: "Rangpur",
    district: "Rangpur",
    address: "Airport Road, Rangpur, Bangladesh",
    latitude: 25.7553,
    longitude: 89.2701,
    images: [
      "https://images.pexels.com/photos/29174542/pexels-photo-29174542.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      "https://images.pexels.com/photos/27459248/pexels-photo-27459248.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      "https://images.pexels.com/photos/6957083/pexels-photo-6957083.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    ],
    amenities: ["Community Garden", "Children's Play Area", "CCTV", "Prayer Room", "Rooftop"],
    features: { "Floor Plan": "2BHK", "Facing": "East", "Handover": "Q4 2025", "Down Payment": "25%" },
    agentId: 2,
    featured: false,
    views: 730,
  },
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: 1,
    clientName: "Mohammad Al-Amin",
    clientTitle: "NRB Investor, UK",
    clientPhoto: "https://images.pexels.com/photos/7641824/pexels-photo-7641824.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=100&w=100",
    quote: "RDAL made my dream of owning property in Bangladesh a reality from the UK. The team's professionalism and transparency gave me complete peace of mind throughout the process.",
    rating: 5,
  },
  {
    id: 2,
    clientName: "Salma Begum",
    clientTitle: "Homeowner, Rangpur",
    clientPhoto: "https://images.pexels.com/photos/7414901/pexels-photo-7414901.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=100&w=100",
    quote: "We moved into our Alyan Dream home on time, exactly as promised. The quality of construction exceeded our expectations. RDAL is truly a company that keeps its word.",
    rating: 5,
  },
  {
    id: 3,
    clientName: "Tanvir Chowdhury",
    clientTitle: "Business Owner, Chittagong",
    clientPhoto: "https://images.pexels.com/photos/12932676/pexels-photo-12932676.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=100&w=100",
    quote: "Their commercial property portfolio is unmatched in northern Bangladesh. Karim helped us find the perfect retail space that has tripled our business visibility.",
    rating: 5,
  },
  {
    id: 4,
    clientName: "Dr. Fariha Islam",
    clientTitle: "Medical Professional, Dhaka",
    clientPhoto: "https://images.pexels.com/photos/8292786/pexels-photo-8292786.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=100&w=100",
    quote: "Investing in a Dhaka apartment through RDAL was the best financial decision of my life. The rental yield has been exceptional and their after-sales support is outstanding.",
    rating: 5,
  },
];

export const SERVICES = [
  {
    icon: "🏗️",
    title: "Property Development",
    description: "End-to-end development of residential complexes, commercial towers, and mixed-use projects with world-class design standards.",
  },
  {
    icon: "🏡",
    title: "Residential Sales",
    description: "Curated portfolio of apartments, villas, and duplexes across Bangladesh's major cities with full legal support.",
  },
  {
    icon: "🏢",
    title: "Commercial Leasing",
    description: "Strategic commercial spaces for retail, hospitality, and corporate occupiers with flexible lease structures.",
  },
  {
    icon: "🌍",
    title: "NRB Investment Services",
    description: "Dedicated desk for Non-Resident Bangladeshis and international investors with multi-currency transactions.",
  },
  {
    icon: "📐",
    title: "Architecture & Design",
    description: "Award-winning in-house architecture team delivering innovative, sustainable, and culturally-rooted building designs.",
  },
  {
    icon: "⚖️",
    title: "Legal & Documentation",
    description: "Complete property registration, title verification, mutation, and documentation services with RAJUK compliance.",
  },
];
