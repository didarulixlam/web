import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatPrice(
  amount: number | string,
  currency: "USD" | "BDT" | "GBP" | "EUR" = "USD",
  locale = "en-US"
): string {
  const num = typeof amount === "string" ? parseFloat(amount) : amount;
  if (isNaN(num)) return "—";

  const currencyMap: Record<string, { locale: string; currency: string }> = {
    USD: { locale: "en-US", currency: "USD" },
    BDT: { locale: "bn-BD", currency: "BDT" },
    GBP: { locale: "en-GB", currency: "GBP" },
    EUR: { locale: "de-DE", currency: "EUR" },
  };
  const cfg = currencyMap[currency] ?? currencyMap.USD;

  return new Intl.NumberFormat(locale ?? cfg.locale, {
    style: "currency",
    currency: cfg.currency,
    maximumFractionDigits: 0,
  }).format(num);
}

export function slugify(text: string) {
  return text
    .toLowerCase()
    .replace(/[^\w\s-]/g, "")
    .replace(/[\s_-]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

export function truncate(str: string, n: number) {
  return str.length > n ? str.slice(0, n - 1) + "…" : str;
}

// BDT ↔ USD approximate conversion rate (2024 avg)
export const BDT_PER_USD = 110;

export function usdToBdt(usd: number) {
  return usd * BDT_PER_USD;
}
