"use client";

import { useState, useEffect, useRef } from "react";
import Link from "next/link";
import { Menu, X, Globe, ChevronDown, Phone } from "lucide-react";
import { cn } from "@/lib/utils";

const NAV_LINKS = [
  { label: "Properties", href: "/properties" },
  { label: "Services", href: "/services" },
  { label: "About", href: "/about" },
  { label: "Agents", href: "/agents" },
  { label: "Testimonials", href: "/testimonials" },
  { label: "Contact", href: "/contact" },
];

const CURRENCIES = ["USD", "BDT", "GBP", "EUR"];

export function Navbar({
  currency,
  onCurrencyChange,
}: {
  currency: string;
  onCurrencyChange: (c: string) => void;
}) {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [currOpen, setCurrOpen] = useState(false);
  const currRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (currRef.current && !currRef.current.contains(e.target as Node)) {
        setCurrOpen(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  return (
    <header
      className={cn(
        "fixed top-0 left-0 right-0 z-50 transition-all duration-300",
        scrolled
          ? "bg-slate-950/95 backdrop-blur-md shadow-lg shadow-black/20 border-b border-white/5"
          : "bg-transparent"
      )}
    >
      <nav
        className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between h-[72px]"
        aria-label="Main navigation"
      >
        {/* Logo */}
        <Link
          href="/"
          className="flex items-center gap-3 group"
          aria-label="RDAL – Home"
        >
          <div className="w-10 h-10 bg-gradient-to-br from-amber-400 to-amber-600 rounded-lg flex items-center justify-center font-bold text-slate-900 text-sm tracking-wider shadow-lg shadow-amber-500/30 group-hover:shadow-amber-500/50 transition-shadow">
            RD
          </div>
          <div className="hidden sm:block">
            <div className="text-white font-bold text-base leading-tight tracking-wide">
              RDAL
            </div>
            <div className="text-amber-400 text-[10px] font-medium tracking-[0.2em] uppercase leading-tight">
              Real Estate
            </div>
          </div>
        </Link>

        {/* Desktop Links */}
        <ul className="hidden lg:flex items-center gap-1" role="menubar">
          {NAV_LINKS.map((link) => (
            <li key={link.href} role="none">
              <Link
                href={link.href}
                role="menuitem"
                className="relative px-4 py-2 text-sm font-medium text-white/80 hover:text-amber-400 transition-colors duration-200 rounded-md hover:bg-white/5 group"
              >
                {link.label}
                <span className="absolute bottom-1 left-4 right-4 h-px bg-amber-400 scale-x-0 group-hover:scale-x-100 transition-transform duration-200 origin-left" />
              </Link>
            </li>
          ))}
        </ul>

        {/* Right Actions */}
        <div className="flex items-center gap-3">
          {/* Currency Selector */}
          <div ref={currRef} className="relative hidden sm:block">
            <button
              onClick={() => setCurrOpen(!currOpen)}
              className="flex items-center gap-1.5 px-3 py-2 text-sm text-white/70 hover:text-amber-400 transition-colors rounded-md hover:bg-white/5 border border-white/10"
              aria-label="Select currency"
              aria-expanded={currOpen}
            >
              <Globe className="w-3.5 h-3.5" />
              <span className="font-medium">{currency}</span>
              <ChevronDown className={cn("w-3 h-3 transition-transform", currOpen && "rotate-180")} />
            </button>
            {currOpen && (
              <div className="absolute top-full right-0 mt-1 bg-slate-900 border border-white/10 rounded-xl shadow-xl overflow-hidden min-w-[100px]">
                {CURRENCIES.map((c) => (
                  <button
                    key={c}
                    onClick={() => { onCurrencyChange(c); setCurrOpen(false); }}
                    className={cn(
                      "w-full px-4 py-2.5 text-sm text-left transition-colors",
                      c === currency
                        ? "bg-amber-500/20 text-amber-400 font-semibold"
                        : "text-white/70 hover:bg-white/5 hover:text-white"
                    )}
                  >
                    {c}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* CTA */}
          <a
            href="tel:+8801711234567"
            className="hidden md:flex items-center gap-2 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-900 font-semibold text-sm rounded-lg transition-colors shadow-lg shadow-amber-500/25"
          >
            <Phone className="w-3.5 h-3.5" />
            Call Us
          </a>

          {/* Mobile Menu */}
          <button
            onClick={() => setOpen(!open)}
            className="lg:hidden p-2 rounded-md text-white hover:bg-white/10 transition-colors"
            aria-label={open ? "Close menu" : "Open menu"}
            aria-expanded={open}
          >
            {open ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </nav>

      {/* Mobile Drawer */}
      <div
        className={cn(
          "lg:hidden overflow-hidden transition-all duration-300 bg-slate-950/98 backdrop-blur-md border-t border-white/5",
          open ? "max-h-screen" : "max-h-0"
        )}
        aria-hidden={!open}
      >
        <div className="px-4 py-4 space-y-1">
          {NAV_LINKS.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              onClick={() => setOpen(false)}
              className="block px-4 py-3 text-white/80 hover:text-amber-400 hover:bg-white/5 rounded-lg transition-colors font-medium"
            >
              {link.label}
            </Link>
          ))}
          <div className="pt-3 border-t border-white/10 flex gap-2 flex-wrap">
            {CURRENCIES.map((c) => (
              <button
                key={c}
                onClick={() => onCurrencyChange(c)}
                className={cn(
                  "px-3 py-1.5 rounded-lg text-sm font-medium transition-colors",
                  c === currency
                    ? "bg-amber-500 text-slate-900"
                    : "border border-white/20 text-white/60 hover:text-white"
                )}
              >
                {c}
              </button>
            ))}
          </div>
        </div>
      </div>
    </header>
  );
}
