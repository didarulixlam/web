"use client";

import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useState } from "react";
import { Send, CheckCircle, AlertCircle, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";

const schema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  email: z.string().email("Please enter a valid email address"),
  phone: z
    .string()
    .optional()
    .refine(
      (val) => !val || /^[+\d\s()-]{6,20}$/.test(val),
      "Please enter a valid phone number"
    ),
  message: z.string().min(10, "Message must be at least 10 characters").max(2000),
  gdprConsent: z.boolean().refine((v) => v === true, {
    message: "You must consent to data processing to submit this form",
  }),
  propertyId: z.string().optional(),
  agentId: z.string().optional(),
});

type FormData = z.infer<typeof schema>;

type Status = "idle" | "loading" | "success" | "error";

export function ContactForm({
  propertyId,
  agentId,
  propertyTitle,
  className,
}: {
  propertyId?: number;
  agentId?: number;
  propertyTitle?: string;
  className?: string;
}) {
  const [status, setStatus] = useState<Status>("idle");
  const [errorMsg, setErrorMsg] = useState("");

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: {
      propertyId: propertyId?.toString(),
      agentId: agentId?.toString(),
    },
  });

  const onSubmit = async (data: FormData) => {
    setStatus("loading");
    try {
      const res = await fetch("/api/leads", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error((err as { message?: string }).message ?? "Submission failed");
      }
      setStatus("success");
      reset();
    } catch (e) {
      setErrorMsg(e instanceof Error ? e.message : "Something went wrong. Please try again.");
      setStatus("error");
    }
  };

  if (status === "success") {
    return (
      <div className={cn("p-8 text-center space-y-4", className)}>
        <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center mx-auto">
          <CheckCircle className="w-8 h-8 text-green-400" />
        </div>
        <h3 className="text-white font-bold text-xl">Message Sent!</h3>
        <p className="text-white/60 text-sm">
          Thank you for your enquiry. Our team will get back to you within 24 hours.
        </p>
        <button
          onClick={() => setStatus("idle")}
          className="px-6 py-2 bg-amber-500 hover:bg-amber-400 text-slate-900 font-semibold rounded-lg transition-colors text-sm"
        >
          Send Another Message
        </button>
      </div>
    );
  }

  return (
    <form
      onSubmit={handleSubmit(onSubmit)}
      className={cn("space-y-4", className)}
      aria-label="Contact form"
      noValidate
    >
      {propertyTitle && (
        <div className="p-3 bg-amber-500/10 border border-amber-500/20 rounded-lg">
          <p className="text-amber-400 text-sm font-medium">
            Enquiry about: <span className="text-white">{propertyTitle}</span>
          </p>
        </div>
      )}

      <input type="hidden" {...register("propertyId")} />
      <input type="hidden" {...register("agentId")} />

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {/* Name */}
        <div>
          <label htmlFor="name" className="block text-white/60 text-xs font-medium mb-1.5">
            Full Name <span className="text-rose-400">*</span>
          </label>
          <input
            id="name"
            type="text"
            autoComplete="name"
            aria-describedby={errors.name ? "name-error" : undefined}
            aria-invalid={!!errors.name}
            {...register("name")}
            className={cn(
              "w-full px-4 py-3 bg-white/5 border rounded-xl text-white placeholder-white/20 text-sm outline-none transition-all",
              errors.name ? "border-rose-500/50 focus:border-rose-500" : "border-white/10 focus:border-amber-500/50"
            )}
            placeholder="Mohammed Rahman"
          />
          {errors.name && (
            <p id="name-error" role="alert" className="mt-1 text-rose-400 text-xs">{errors.name.message}</p>
          )}
        </div>

        {/* Email */}
        <div>
          <label htmlFor="email" className="block text-white/60 text-xs font-medium mb-1.5">
            Email Address <span className="text-rose-400">*</span>
          </label>
          <input
            id="email"
            type="email"
            autoComplete="email"
            aria-describedby={errors.email ? "email-error" : undefined}
            aria-invalid={!!errors.email}
            {...register("email")}
            className={cn(
              "w-full px-4 py-3 bg-white/5 border rounded-xl text-white placeholder-white/20 text-sm outline-none transition-all",
              errors.email ? "border-rose-500/50 focus:border-rose-500" : "border-white/10 focus:border-amber-500/50"
            )}
            placeholder="email@example.com"
          />
          {errors.email && (
            <p id="email-error" role="alert" className="mt-1 text-rose-400 text-xs">{errors.email.message}</p>
          )}
        </div>
      </div>

      {/* Phone */}
      <div>
        <label htmlFor="phone" className="block text-white/60 text-xs font-medium mb-1.5">
          Phone Number <span className="text-white/30">(optional)</span>
        </label>
        <input
          id="phone"
          type="tel"
          autoComplete="tel"
          aria-describedby={errors.phone ? "phone-error" : undefined}
          aria-invalid={!!errors.phone}
          {...register("phone")}
          className={cn(
            "w-full px-4 py-3 bg-white/5 border rounded-xl text-white placeholder-white/20 text-sm outline-none transition-all",
            errors.phone ? "border-rose-500/50 focus:border-rose-500" : "border-white/10 focus:border-amber-500/50"
          )}
          placeholder="+880 17XX XXXXXX"
        />
        {errors.phone && (
          <p id="phone-error" role="alert" className="mt-1 text-rose-400 text-xs">{errors.phone.message}</p>
        )}
      </div>

      {/* Message */}
      <div>
        <label htmlFor="message" className="block text-white/60 text-xs font-medium mb-1.5">
          Message <span className="text-rose-400">*</span>
        </label>
        <textarea
          id="message"
          rows={4}
          aria-describedby={errors.message ? "message-error" : undefined}
          aria-invalid={!!errors.message}
          {...register("message")}
          className={cn(
            "w-full px-4 py-3 bg-white/5 border rounded-xl text-white placeholder-white/20 text-sm outline-none transition-all resize-none",
            errors.message ? "border-rose-500/50 focus:border-rose-500" : "border-white/10 focus:border-amber-500/50"
          )}
          placeholder="I'm interested in this property and would like to schedule a viewing…"
        />
        {errors.message && (
          <p id="message-error" role="alert" className="mt-1 text-rose-400 text-xs">{errors.message.message}</p>
        )}
      </div>

      {/* GDPR Consent */}
      <div className="p-4 bg-slate-800/50 border border-white/5 rounded-xl">
        <label className="flex gap-3 cursor-pointer group">
          <input
            type="checkbox"
            aria-describedby={errors.gdprConsent ? "gdpr-error" : undefined}
            aria-invalid={!!errors.gdprConsent}
            {...register("gdprConsent")}
            className="mt-0.5 w-4 h-4 accent-amber-500 cursor-pointer"
          />
          <span className="text-white/50 text-xs leading-relaxed group-hover:text-white/70 transition-colors">
            I consent to RDAL processing my personal data (name, email, phone) to respond to my enquiry.
            My data will be held securely and not shared with third parties without consent.
            See our{" "}
            <a href="/privacy" className="text-amber-400 underline hover:text-amber-300">Privacy Policy</a>.
            {" "}<span className="text-rose-400">*</span>
          </span>
        </label>
        {errors.gdprConsent && (
          <p id="gdpr-error" role="alert" className="mt-2 text-rose-400 text-xs">{errors.gdprConsent.message}</p>
        )}
      </div>

      {/* Error banner */}
      {status === "error" && (
        <div className="flex items-center gap-3 p-4 bg-rose-500/10 border border-rose-500/30 rounded-xl" role="alert">
          <AlertCircle className="w-5 h-5 text-rose-400 shrink-0" />
          <p className="text-rose-400 text-sm">{errorMsg}</p>
        </div>
      )}

      {/* Submit */}
      <button
        type="submit"
        disabled={status === "loading"}
        className="w-full flex items-center justify-center gap-2 py-3.5 bg-amber-500 hover:bg-amber-400 disabled:opacity-60 disabled:cursor-not-allowed text-slate-900 font-bold rounded-xl transition-all shadow-lg shadow-amber-500/20 hover:shadow-amber-500/30"
      >
        {status === "loading" ? (
          <>
            <Loader2 className="w-4 h-4 animate-spin" />
            Sending…
          </>
        ) : (
          <>
            <Send className="w-4 h-4" />
            Send Enquiry
          </>
        )}
      </button>

      <p className="text-white/20 text-xs text-center">
        🔒 Your information is encrypted and secure. We respond within 24 hours.
      </p>
    </form>
  );
}
