"use client";

import { createContext, useContext, useState, type ReactNode } from "react";

type Currency = "USD" | "BDT" | "GBP" | "EUR";

interface CurrencyCtx {
  currency: Currency;
  setCurrency: (c: string) => void;
}

const Ctx = createContext<CurrencyCtx>({ currency: "USD", setCurrency: () => {} });

export function CurrencyProvider({ children }: { children: ReactNode }) {
  const [currency, setCurrencyState] = useState<Currency>("USD");
  const setCurrency = (c: string) => setCurrencyState(c as Currency);
  return <Ctx.Provider value={{ currency, setCurrency }}>{children}</Ctx.Provider>;
}

export function useCurrency() {
  return useContext(Ctx);
}
