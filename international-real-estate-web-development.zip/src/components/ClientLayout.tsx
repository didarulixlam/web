"use client";

import { CurrencyProvider, useCurrency } from "./CurrencyContext";
import { Navbar } from "./Navbar";
import { Footer } from "./Footer";
import type { ReactNode } from "react";

function LayoutInner({ children }: { children: ReactNode }) {
  const { currency, setCurrency } = useCurrency();
  return (
    <>
      <Navbar currency={currency} onCurrencyChange={setCurrency} />
      <main id="main-content" tabIndex={-1}>
        {children}
      </main>
      <Footer />
    </>
  );
}

export function ClientLayout({ children }: { children: ReactNode }) {
  return (
    <CurrencyProvider>
      <LayoutInner>{children}</LayoutInner>
    </CurrencyProvider>
  );
}
