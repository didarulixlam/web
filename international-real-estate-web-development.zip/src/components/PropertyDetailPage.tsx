"use client";

import { useState } from "react";
import Link from "next/link";
import {
  MapPin,
  Bed,
  Bath,
  Maximize,
  Calendar,
  Car,
  Sofa,
  Layers,
  Eye,
  Share2,
  ChevronLeft,
  ChevronRight,
  Check,
  ArrowLeft,
} from "lucide-react";
import { MapStub } from "./MapStub";
import { ContactForm } from "./ContactForm";
import { AgentCard } from "./AgentCard";
import { PropertyCard } from "./PropertyCard";
import { useCurrency } from "./CurrencyContext";
import { formatPrice } from "@/lib/utils";
import { AGENTS, PROPERTIES, type Property } from "@/lib/mock-data";
import { GradientOrbs } from "./AnimatedBackground";

// ── Image Gallery ─────────────────────────────────────────────────────────────
function Gallery({ images, title }: { images: string[]; title: string }) {
  const [current, setCurrent] = useState(0);
  const [lightbox, setLightbox] = useState(false);

  const prev = () => setCurrent((i) => (i - 1 + images.length) % images.length);
  const next = () => setCurrent((i) => (i + 1) % images.length);

  return (
    <>
      <div className="relative h-72 sm:h-96 lg:h-[520px] rounded-2xl overflow-hidden group">
        <img
          src={images[current]}
          alt={`${title} – image ${current + 1}`}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />

        {/* Nav arrows */}
        {images.length > 1 && (
          <>
            <button
              onClick={prev}
              aria-label="Previous image"
              className="absolute left-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-black/50 backdrop-blur-sm text-white hover:bg-black/70 flex items-center justify-center transition-all opacity-0 group-hover:opacity-100"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button
              onClick={next}
              aria-label="Next image"
              className="absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-black/50 backdrop-blur-sm text-white hover:bg-black/70 flex items-center justify-center transition-all opacity-0 group-hover:opacity-100"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </>
        )}

        {/* Counter */}
        <div className="absolute bottom-4 right-4 px-3 py-1.5 bg-black/60 backdrop-blur-sm rounded-lg text-white text-xs font-medium">
          {current + 1} / {images.length}
        </div>

        {/* Expand */}
        <button
          onClick={() => setLightbox(true)}
          className="absolute bottom-4 left-4 px-3 py-1.5 bg-black/60 backdrop-blur-sm rounded-lg text-white text-xs font-medium hover:bg-black/80 transition-colors"
          aria-label="View fullscreen"
        >
          View Full Gallery
        </button>
      </div>

      {/* Thumbnails */}
      <div className="flex gap-2 mt-3 overflow-x-auto pb-1">
        {images.map((img, i) => (
          <button
            key={i}
            onClick={() => setCurrent(i)}
            aria-label={`View image ${i + 1}`}
            aria-pressed={i === current}
            className={`relative shrink-0 w-20 h-16 rounded-xl overflow-hidden border-2 transition-all ${
              i === current ? "border-amber-500" : "border-transparent opacity-60 hover:opacity-100"
            }`}
          >
            <img src={img} alt="" className="w-full h-full object-cover" />
          </button>
        ))}
      </div>

      {/* Lightbox */}
      {lightbox && (
        <div
          className="fixed inset-0 z-50 bg-black/95 flex items-center justify-center p-4"
          onClick={() => setLightbox(false)}
          role="dialog"
          aria-modal="true"
          aria-label={`Image gallery for ${title}`}
        >
          <button
            className="absolute top-4 right-4 text-white/60 hover:text-white text-sm"
            onClick={() => setLightbox(false)}
            aria-label="Close gallery"
          >
            ✕ Close
          </button>
          <button onClick={(e) => { e.stopPropagation(); prev(); }} aria-label="Previous" className="absolute left-4 w-12 h-12 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors">
            <ChevronLeft className="w-6 h-6" />
          </button>
          <img
            src={images[current]}
            alt={`${title} – ${current + 1}`}
            className="max-w-full max-h-full object-contain rounded-xl"
            onClick={(e) => e.stopPropagation()}
          />
          <button onClick={(e) => { e.stopPropagation(); next(); }} aria-label="Next" className="absolute right-4 w-12 h-12 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors">
            <ChevronRight className="w-6 h-6" />
          </button>
        </div>
      )}
    </>
  );
}

// ── Property Detail Page ──────────────────────────────────────────────────────
export function PropertyDetailPage({ property }: { property: Property }) {
  const { currency } = useCurrency();
  const agent = AGENTS.find((a) => a.id === property.agentId);
  const similar = PROPERTIES.filter(
    (p) => p.id !== property.id && p.type === property.type
  ).slice(0, 4);

  const displayPrice =
    currency === "BDT"
      ? formatPrice(property.priceBDT, "BDT")
      : currency === "GBP"
      ? formatPrice(property.priceUSD * 0.79, "GBP")
      : currency === "EUR"
      ? formatPrice(property.priceUSD * 0.92, "EUR")
      : formatPrice(property.priceUSD, "USD");

  const [copied, setCopied] = useState(false);
  const share = async () => {
    try {
      await navigator.clipboard.writeText(window.location.href);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      /* ignore */
    }
  };

  return (
    <div className="min-h-screen pt-20">
      {/* Breadcrumb */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <nav aria-label="Breadcrumb">
          <ol className="flex items-center gap-2 text-sm text-white/40">
            <li><Link href="/" className="hover:text-amber-400 transition-colors">Home</Link></li>
            <li>/</li>
            <li><Link href="/properties" className="hover:text-amber-400 transition-colors">Properties</Link></li>
            <li>/</li>
            <li className="text-white/70 truncate max-w-48">{property.title}</li>
          </ol>
        </nav>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-16">
        {/* Back */}
        <Link
          href="/properties"
          className="inline-flex items-center gap-2 text-white/50 hover:text-amber-400 transition-colors text-sm mb-6"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to listings
        </Link>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Left Column */}
          <div className="lg:col-span-2 space-y-8">
            {/* Gallery */}
            <Gallery images={property.images} title={property.title} />

            {/* Title & Price block */}
            <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
              <div>
                <div className="flex flex-wrap gap-2 mb-3">
                  <span className="px-3 py-1 text-xs font-semibold rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 capitalize">
                    {property.type}
                  </span>
                  <span className={`px-3 py-1 text-xs font-semibold rounded-full ${property.listingType === "rent" ? "bg-teal-500/20 text-teal-300 border border-teal-500/30" : "bg-blue-500/20 text-blue-300 border border-blue-500/30"}`}>
                    For {property.listingType === "rent" ? "Rent" : "Sale"}
                  </span>
                  <span className={`px-3 py-1 text-xs font-semibold rounded-full capitalize ${property.status === "available" ? "bg-green-500/20 text-green-300 border border-green-500/30" : "bg-rose-500/20 text-rose-300 border border-rose-500/30"}`}>
                    {property.status}
                  </span>
                </div>
                <h1 className="text-2xl sm:text-3xl font-bold text-white mb-2">{property.title}</h1>
                <div className="flex items-center gap-2 text-white/50 text-sm">
                  <MapPin className="w-4 h-4 text-amber-400 shrink-0" />
                  {property.address}
                </div>
              </div>
              <div className="text-right shrink-0">
                <div className="text-amber-400 font-bold text-3xl">
                  {displayPrice}
                  {property.listingType === "rent" && <span className="text-base text-white/40 font-normal">/mo</span>}
                </div>
                {property.areaSqft && (
                  <div className="text-white/30 text-sm mt-1">
                    {formatPrice(property.priceUSD / property.areaSqft, "USD")}/sqft
                  </div>
                )}
                <div className="flex items-center gap-2 justify-end mt-2 text-white/40 text-xs">
                  <Eye className="w-3.5 h-3.5" />
                  {property.views.toLocaleString()} views
                </div>
              </div>
            </div>

            {/* Key Stats */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              {[
                { icon: Bed, label: "Bedrooms", value: property.bedrooms > 0 ? property.bedrooms : "N/A" },
                { icon: Bath, label: "Bathrooms", value: property.bathrooms > 0 ? property.bathrooms : "N/A" },
                { icon: Maximize, label: "Area (sqft)", value: property.areaSqft?.toLocaleString() ?? "N/A" },
                { icon: Layers, label: "Floors", value: property.floors ?? "N/A" },
                { icon: Car, label: "Parking", value: property.parking ? "Yes" : "No" },
                { icon: Sofa, label: "Furnished", value: property.furnished ? "Yes" : "No" },
                { icon: Calendar, label: "Year Built", value: property.yearBuilt ?? "TBD" },
                { icon: Eye, label: "Views", value: property.views.toLocaleString() },
              ].map(({ icon: Icon, label, value }) => (
                <div key={label} className="bg-slate-900 rounded-xl p-4 border border-white/5">
                  <Icon className="w-4 h-4 text-amber-400 mb-2" />
                  <div className="text-white font-semibold text-base">{value}</div>
                  <div className="text-white/40 text-xs">{label}</div>
                </div>
              ))}
            </div>

            {/* Description */}
            <div>
              <h2 className="text-white font-bold text-xl mb-4">About This Property</h2>
              <p className="text-white/60 leading-relaxed">{property.description}</p>
            </div>

            {/* Amenities */}
            <div>
              <h2 className="text-white font-bold text-xl mb-4">Amenities & Features</h2>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {property.amenities.map((amenity) => (
                  <div key={amenity} className="flex items-center gap-2 text-white/70 text-sm">
                    <Check className="w-4 h-4 text-amber-400 shrink-0" />
                    {amenity}
                  </div>
                ))}
              </div>
            </div>

            {/* Additional Features */}
            {Object.keys(property.features).length > 0 && (
              <div>
                <h2 className="text-white font-bold text-xl mb-4">Property Details</h2>
                <div className="grid grid-cols-2 gap-4">
                  {Object.entries(property.features).map(([key, value]) => (
                    <div key={key} className="flex justify-between gap-2 py-3 border-b border-white/5">
                      <span className="text-white/40 text-sm">{key}</span>
                      <span className="text-white text-sm font-medium text-right">{value}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Map */}
            <div>
              <h2 className="text-white font-bold text-xl mb-4">Location</h2>
              <MapStub
                latitude={property.latitude}
                longitude={property.longitude}
                title={property.title}
                address={property.address}
              />
            </div>

            {/* Share */}
            <button
              onClick={share}
              className="flex items-center gap-2 text-white/50 hover:text-amber-400 transition-colors text-sm"
            >
              <Share2 className="w-4 h-4" />
              {copied ? "Link Copied!" : "Share Property"}
            </button>
          </div>

          {/* Right Sidebar */}
          <div className="space-y-6">
            {/* Contact Form */}
            <div className="bg-slate-900 rounded-2xl border border-white/5 p-6 sticky top-24">
              <h2 className="text-white font-bold text-lg mb-5">
                Enquire About This Property
              </h2>
              <ContactForm
                propertyId={property.id}
                agentId={property.agentId}
                propertyTitle={property.title}
              />
            </div>

            {/* Agent Card */}
            {agent && (
              <div>
                <h2 className="text-white font-bold text-lg mb-3">Listed By</h2>
                <AgentCard agent={agent} />
              </div>
            )}
          </div>
        </div>

        {/* Similar Properties */}
        {similar.length > 0 && (
          <section className="mt-16" aria-labelledby="similar-heading">
            <div className="flex items-end justify-between mb-8">
              <div>
                <h2 id="similar-heading" className="text-2xl font-bold text-white">Similar Properties</h2>
                <p className="text-white/40 text-sm mt-1">You might also be interested in these</p>
              </div>
              <Link href="/properties" className="text-amber-400 hover:text-amber-300 text-sm font-medium transition-colors">
                View All →
              </Link>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {similar.map((p) => (
                <PropertyCard key={p.id} property={p} currency={currency} />
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
}
