"use client";

import { useState, useMemo, useEffect } from "react";
import { LayoutGrid, List, ArrowUpDown } from "lucide-react";
import { SearchFilters, DEFAULT_FILTERS, type FilterState } from "./SearchFilters";
import { PropertyCard } from "./PropertyCard";
import { useCurrency } from "./CurrencyContext";
import { PROPERTIES } from "@/lib/mock-data";
import { cn } from "@/lib/utils";
import { GradientOrbs } from "./AnimatedBackground";

type SortKey = "featured" | "price-asc" | "price-desc" | "newest" | "views";

export function PropertiesPage() {
  const { currency } = useCurrency();
  const [filters, setFilters] = useState<FilterState>(DEFAULT_FILTERS);
  const [sort, setSort] = useState<SortKey>("featured");
  const [view, setView] = useState<"grid" | "list">("grid");
  const [page, setPage] = useState(1);
  const PER_PAGE = 8;

  // Reset page when filters change
  useEffect(() => setPage(1), [filters]);

  const filtered = useMemo(() => {
    let results = [...PROPERTIES];

    if (filters.query) {
      const q = filters.query.toLowerCase();
      results = results.filter(
        (p) =>
          p.title.toLowerCase().includes(q) ||
          p.city.toLowerCase().includes(q) ||
          p.address.toLowerCase().includes(q) ||
          p.description.toLowerCase().includes(q)
      );
    }
    if (filters.type) results = results.filter((p) => p.type === filters.type);
    if (filters.listingType) results = results.filter((p) => p.listingType === filters.listingType);
    if (filters.city) results = results.filter((p) => p.city === filters.city);
    if (filters.minPrice) results = results.filter((p) => p.priceUSD >= parseFloat(filters.minPrice));
    if (filters.maxPrice) results = results.filter((p) => p.priceUSD <= parseFloat(filters.maxPrice));
    if (filters.minBeds) {
      const beds = parseInt(filters.minBeds.replace("+", ""));
      results = results.filter((p) => p.bedrooms >= beds);
    }
    if (filters.minBaths) {
      const baths = parseInt(filters.minBaths.replace("+", ""));
      results = results.filter((p) => p.bathrooms >= baths);
    }
    if (filters.furnished === "yes") results = results.filter((p) => p.furnished);
    if (filters.furnished === "no") results = results.filter((p) => !p.furnished);

    // Sort
    results.sort((a, b) => {
      switch (sort) {
        case "price-asc": return a.priceUSD - b.priceUSD;
        case "price-desc": return b.priceUSD - a.priceUSD;
        case "newest": return b.id - a.id;
        case "views": return b.views - a.views;
        case "featured": return (b.featured ? 1 : 0) - (a.featured ? 1 : 0);
        default: return 0;
      }
    });

    return results;
  }, [filters, sort]);

  const totalPages = Math.ceil(filtered.length / PER_PAGE);
  const paginated = filtered.slice((page - 1) * PER_PAGE, page * PER_PAGE);

  return (
    <div className="min-h-screen pt-20">
      {/* Hero */}
      <section className="relative py-16 overflow-hidden border-b border-white/5">
        <GradientOrbs />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <span className="text-amber-400 text-sm font-semibold uppercase tracking-widest block mb-2">
            Property Listings
          </span>
          <h1 className="text-3xl sm:text-5xl font-bold text-white mb-4">
            Find Your Perfect Property
          </h1>
          <p className="text-white/50 max-w-xl">
            Browse {PROPERTIES.length}+ premium listings across Bangladesh.
            Use the filters below to narrow your search.
          </p>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Filters */}
        <SearchFilters filters={filters} onChange={setFilters} className="mb-8" />

        {/* Toolbar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <p className="text-white/50 text-sm">
            <span className="text-white font-semibold">{filtered.length}</span> propert{filtered.length !== 1 ? "ies" : "y"} found
          </p>

          <div className="flex items-center gap-3">
            {/* Sort */}
            <div className="flex items-center gap-2">
              <ArrowUpDown className="w-4 h-4 text-white/40" />
              <select
                value={sort}
                onChange={(e) => setSort(e.target.value as SortKey)}
                aria-label="Sort properties"
                className="bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-white text-sm outline-none focus:border-amber-500/50 transition-all"
              >
                <option value="featured">Featured First</option>
                <option value="price-asc">Price: Low to High</option>
                <option value="price-desc">Price: High to Low</option>
                <option value="newest">Newest</option>
                <option value="views">Most Viewed</option>
              </select>
            </div>

            {/* View toggle */}
            <div className="flex gap-1 p-1 bg-white/5 rounded-lg border border-white/10">
              <button
                onClick={() => setView("grid")}
                aria-label="Grid view"
                aria-pressed={view === "grid"}
                className={cn("p-2 rounded-md transition-all", view === "grid" ? "bg-amber-500 text-slate-900" : "text-white/50 hover:text-white")}
              >
                <LayoutGrid className="w-4 h-4" />
              </button>
              <button
                onClick={() => setView("list")}
                aria-label="List view"
                aria-pressed={view === "list"}
                className={cn("p-2 rounded-md transition-all", view === "list" ? "bg-amber-500 text-slate-900" : "text-white/50 hover:text-white")}
              >
                <List className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Grid / List */}
        {paginated.length === 0 ? (
          <div className="text-center py-24">
            <div className="text-6xl mb-4">🏠</div>
            <h3 className="text-white font-bold text-xl mb-2">No Properties Found</h3>
            <p className="text-white/50 text-sm">Try adjusting your filters to see more results.</p>
          </div>
        ) : (
          <div
            className={cn(
              "gap-6",
              view === "grid"
                ? "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4"
                : "flex flex-col"
            )}
          >
            {paginated.map((p) => (
              <PropertyCard
                key={p.id}
                property={p}
                currency={currency}
                className={view === "list" ? "flex-row sm:flex-row" : ""}
              />
            ))}
          </div>
        )}

        {/* Pagination */}
        {totalPages > 1 && (
          <nav className="flex items-center justify-center gap-2 mt-12" aria-label="Pagination">
            <button
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page === 1}
              className="px-4 py-2 rounded-lg bg-white/5 border border-white/10 text-white/60 hover:text-white hover:border-amber-500/30 disabled:opacity-30 disabled:cursor-not-allowed transition-all text-sm"
            >
              Previous
            </button>
            {[...Array(totalPages)].map((_, i) => (
              <button
                key={i}
                onClick={() => setPage(i + 1)}
                aria-current={page === i + 1 ? "page" : undefined}
                className={cn(
                  "w-9 h-9 rounded-lg text-sm font-medium transition-all",
                  page === i + 1
                    ? "bg-amber-500 text-slate-900"
                    : "bg-white/5 border border-white/10 text-white/60 hover:text-white hover:border-amber-500/30"
                )}
              >
                {i + 1}
              </button>
            ))}
            <button
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              disabled={page === totalPages}
              className="px-4 py-2 rounded-lg bg-white/5 border border-white/10 text-white/60 hover:text-white hover:border-amber-500/30 disabled:opacity-30 disabled:cursor-not-allowed transition-all text-sm"
            >
              Next
            </button>
          </nav>
        )}
      </div>
    </div>
  );
}
