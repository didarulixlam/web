import Link from "next/link";
import { MapPin, Phone, Mail, ArrowRight } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-slate-950 border-t border-white/5" role="contentinfo">
      {/* Newsletter bar */}
      <div className="bg-gradient-to-r from-amber-600 to-amber-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 flex flex-col md:flex-row items-center justify-between gap-6">
          <div>
            <h3 className="text-slate-900 font-bold text-xl">Stay Ahead of the Market</h3>
            <p className="text-slate-900/70 text-sm mt-1">
              Get exclusive listings and market insights delivered to your inbox.
            </p>
          </div>
          <form className="flex gap-2 w-full md:w-auto" onSubmit={(e) => e.preventDefault()}>
            <input
              type="email"
              placeholder="Your email address"
              aria-label="Email for newsletter"
              className="flex-1 md:w-72 px-4 py-2.5 rounded-lg bg-white text-slate-900 placeholder-slate-400 text-sm outline-none focus:ring-2 focus:ring-slate-900/30"
            />
            <button
              type="submit"
              className="px-5 py-2.5 bg-slate-900 text-white text-sm font-semibold rounded-lg hover:bg-slate-800 transition-colors flex items-center gap-2"
            >
              Subscribe <ArrowRight className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>

      {/* Main footer */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
        {/* Brand */}
        <div className="lg:col-span-1">
          <Link href="/" className="flex items-center gap-3 mb-5">
            <div className="w-10 h-10 bg-gradient-to-br from-amber-400 to-amber-600 rounded-lg flex items-center justify-center font-bold text-slate-900 text-sm">
              RD
            </div>
            <div>
              <div className="text-white font-bold leading-tight">RDAL</div>
              <div className="text-amber-400 text-[10px] font-medium tracking-[0.2em] uppercase">
                Rangpur Architectural Design
              </div>
            </div>
          </Link>
          <p className="text-white/50 text-sm leading-relaxed mb-6">
            Bangladesh&apos;s premier real estate developer — building quality homes
            and commercial spaces with integrity since 2010.
          </p>
          <div className="flex gap-3">
            {[
              { emoji: "f", label: "Facebook", href: "#" },
              { emoji: "in", label: "Instagram", href: "#" },
              { emoji: "li", label: "LinkedIn", href: "#" },
              { emoji: "𝕏", label: "Twitter / X", href: "#" },
            ].map(({ emoji, label, href }) => (
              <a
                key={label}
                href={href}
                aria-label={label}
                className="w-9 h-9 rounded-lg bg-white/5 hover:bg-amber-500/20 border border-white/10 hover:border-amber-500/30 flex items-center justify-center text-white/50 hover:text-amber-400 transition-all duration-200 text-xs font-bold"
              >
                {emoji}
              </a>
            ))}
          </div>
        </div>

        {/* Quick Links */}
        <div>
          <h4 className="text-white font-semibold text-sm uppercase tracking-wider mb-5">
            Quick Links
          </h4>
          <ul className="space-y-3">
            {[
              { label: "Browse Properties", href: "/properties" },
              { label: "Our Services", href: "/services" },
              { label: "About RDAL", href: "/about" },
              { label: "Meet Our Agents", href: "/agents" },
              { label: "Testimonials", href: "/testimonials" },
              { label: "Contact Us", href: "/contact" },
            ].map(({ label, href }) => (
              <li key={href}>
                <Link
                  href={href}
                  className="text-white/50 hover:text-amber-400 text-sm transition-colors flex items-center gap-2 group"
                >
                  <ArrowRight className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" />
                  {label}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        {/* Property Types */}
        <div>
          <h4 className="text-white font-semibold text-sm uppercase tracking-wider mb-5">
            Property Types
          </h4>
          <ul className="space-y-3">
            {["Apartments", "Villas", "Duplexes", "Commercial Spaces", "Land & Plots", "Luxury Penthouses"].map(
              (item) => (
                <li key={item}>
                  <Link
                    href={`/properties?type=${item.toLowerCase().split(" ")[0]}`}
                    className="text-white/50 hover:text-amber-400 text-sm transition-colors flex items-center gap-2 group"
                  >
                    <ArrowRight className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" />
                    {item}
                  </Link>
                </li>
              )
            )}
          </ul>
        </div>

        {/* Contact */}
        <div>
          <h4 className="text-white font-semibold text-sm uppercase tracking-wider mb-5">
            Contact
          </h4>
          <ul className="space-y-4">
            <li>
              <a
                href="https://maps.google.com/?q=Rangpur+Bangladesh"
                target="_blank"
                rel="noopener noreferrer"
                className="flex gap-3 text-white/50 hover:text-white transition-colors text-sm"
              >
                <MapPin className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <span>Munshipara, Rangpur City<br />Rangpur Division, Bangladesh</span>
              </a>
            </li>
            <li>
              <a href="tel:+8801711234567" className="flex gap-3 text-white/50 hover:text-amber-400 transition-colors text-sm">
                <Phone className="w-4 h-4 text-amber-400 shrink-0" />
                +880 1711-234567
              </a>
            </li>
            <li>
              <a href="mailto:info@rdal.com.bd" className="flex gap-3 text-white/50 hover:text-amber-400 transition-colors text-sm">
                <Mail className="w-4 h-4 text-amber-400 shrink-0" />
                info@rdal.com.bd
              </a>
            </li>
          </ul>
          <div className="mt-6 p-3 bg-green-500/10 border border-green-500/20 rounded-lg">
            <p className="text-green-400 text-xs font-semibold">🟢 Office Open</p>
            <p className="text-white/40 text-xs mt-1">Sat–Thu, 9AM – 6PM BST</p>
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-white/5 py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-white/30 text-xs">
          <p>© {new Date().getFullYear()} Rangpur Architectural Design Ltd. (RDAL). All rights reserved.</p>
          <div className="flex gap-4">
            <Link href="/privacy" className="hover:text-white transition-colors">Privacy Policy</Link>
            <Link href="/terms" className="hover:text-white transition-colors">Terms of Service</Link>
            <Link href="/sitemap" className="hover:text-white transition-colors">Sitemap</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
