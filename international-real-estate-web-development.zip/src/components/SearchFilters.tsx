"use client";

import { useState } from "react";
import { Search, SlidersHorizontal, X, ChevronDown } from "lucide-react";
import { cn } from "@/lib/utils";

export interface FilterState {
  query: string;
  type: string;
  listingType: string;
  city: string;
  minPrice: string;
  maxPrice: string;
  minBeds: string;
  minBaths: string;
  furnished: string;
  status: string;
}

const DEFAULT_FILTERS: FilterState = {
  query: "",
  type: "",
  listingType: "",
  city: "",
  minPrice: "",
  maxPrice: "",
  minBeds: "",
  minBaths: "",
  furnished: "",
  status: "available",
};

const CITIES = ["Rangpur", "Dhaka", "Chittagong", "Rajshahi", "Sylhet", "Khulna"];
const TYPES = ["apartment", "villa", "commercial", "land", "duplex"];
const BED_OPTIONS = ["1", "2", "3", "4", "5+"];

export function SearchFilters({
  filters,
  onChange,
  className,
}: {
  filters: FilterState;
  onChange: (f: FilterState) => void;
  className?: string;
}) {
  const [expanded, setExpanded] = useState(false);

  const update = (key: keyof FilterState, value: string) =>
    onChange({ ...filters, [key]: value });

  const reset = () => onChange(DEFAULT_FILTERS);

  const activeCount = Object.entries(filters).filter(
    ([k, v]) => k !== "status" && v !== "" && v !== DEFAULT_FILTERS[k as keyof FilterState]
  ).length;

  return (
    <div className={cn("bg-slate-900/80 backdrop-blur-md border border-white/10 rounded-2xl p-5 shadow-2xl shadow-black/20", className)}>
      {/* Top Row */}
      <div className="flex flex-col sm:flex-row gap-3">
        {/* Search */}
        <div className="relative flex-1">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-white/40" />
          <input
            type="search"
            value={filters.query}
            onChange={(e) => update("query", e.target.value)}
            placeholder="Search by title, address, city…"
            aria-label="Search properties"
            className="w-full pl-10 pr-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-white/30 text-sm outline-none focus:border-amber-500/50 focus:bg-white/8 transition-all"
          />
          {filters.query && (
            <button onClick={() => update("query", "")} className="absolute right-3 top-1/2 -translate-y-1/2 text-white/30 hover:text-white transition-colors">
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Listing Type toggle */}
        <div className="flex gap-1 p-1 bg-white/5 rounded-xl border border-white/10">
          {["", "sale", "rent"].map((lt) => (
            <button
              key={lt}
              onClick={() => update("listingType", lt)}
              className={cn(
                "px-4 py-2 rounded-lg text-sm font-medium transition-all",
                filters.listingType === lt
                  ? "bg-amber-500 text-slate-900"
                  : "text-white/50 hover:text-white"
              )}
            >
              {lt === "" ? "All" : lt.charAt(0).toUpperCase() + lt.slice(1)}
            </button>
          ))}
        </div>

        {/* Filter toggle */}
        <button
          onClick={() => setExpanded(!expanded)}
          className={cn(
            "flex items-center gap-2 px-4 py-2 rounded-xl border text-sm font-medium transition-all",
            expanded || activeCount > 0
              ? "border-amber-500/50 bg-amber-500/10 text-amber-400"
              : "border-white/10 text-white/60 hover:text-white hover:border-white/20"
          )}
          aria-expanded={expanded}
          aria-label="Toggle advanced filters"
        >
          <SlidersHorizontal className="w-4 h-4" />
          Filters
          {activeCount > 0 && (
            <span className="w-5 h-5 bg-amber-500 text-slate-900 rounded-full text-xs font-bold flex items-center justify-center">
              {activeCount}
            </span>
          )}
          <ChevronDown className={cn("w-4 h-4 transition-transform", expanded && "rotate-180")} />
        </button>
      </div>

      {/* Expanded filters */}
      <div
        className={cn(
          "overflow-hidden transition-all duration-300",
          expanded ? "max-h-[600px] mt-4" : "max-h-0"
        )}
      >
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 pt-4 border-t border-white/5">
          {/* Property Type */}
          <div>
            <label className="text-white/50 text-xs font-medium block mb-1.5">Property Type</label>
            <select
              value={filters.type}
              onChange={(e) => update("type", e.target.value)}
              className="w-full px-3 py-2.5 bg-white/5 border border-white/10 rounded-lg text-white text-sm outline-none focus:border-amber-500/50 transition-all"
            >
              <option value="">All Types</option>
              {TYPES.map((t) => (
                <option key={t} value={t} className="bg-slate-900 capitalize">{t.charAt(0).toUpperCase() + t.slice(1)}</option>
              ))}
            </select>
          </div>

          {/* City */}
          <div>
            <label className="text-white/50 text-xs font-medium block mb-1.5">City</label>
            <select
              value={filters.city}
              onChange={(e) => update("city", e.target.value)}
              className="w-full px-3 py-2.5 bg-white/5 border border-white/10 rounded-lg text-white text-sm outline-none focus:border-amber-500/50 transition-all"
            >
              <option value="">All Cities</option>
              {CITIES.map((c) => (
                <option key={c} value={c} className="bg-slate-900">{c}</option>
              ))}
            </select>
          </div>

          {/* Min Price */}
          <div>
            <label className="text-white/50 text-xs font-medium block mb-1.5">Min Price (USD)</label>
            <input
              type="number"
              value={filters.minPrice}
              onChange={(e) => update("minPrice", e.target.value)}
              placeholder="0"
              min="0"
              className="w-full px-3 py-2.5 bg-white/5 border border-white/10 rounded-lg text-white placeholder-white/20 text-sm outline-none focus:border-amber-500/50 transition-all"
            />
          </div>

          {/* Max Price */}
          <div>
            <label className="text-white/50 text-xs font-medium block mb-1.5">Max Price (USD)</label>
            <input
              type="number"
              value={filters.maxPrice}
              onChange={(e) => update("maxPrice", e.target.value)}
              placeholder="Any"
              min="0"
              className="w-full px-3 py-2.5 bg-white/5 border border-white/10 rounded-lg text-white placeholder-white/20 text-sm outline-none focus:border-amber-500/50 transition-all"
            />
          </div>

          {/* Min Beds */}
          <div>
            <label className="text-white/50 text-xs font-medium block mb-1.5">Min Bedrooms</label>
            <div className="flex gap-1">
              {["", ...BED_OPTIONS].map((b) => (
                <button
                  key={b}
                  onClick={() => update("minBeds", b)}
                  className={cn(
                    "flex-1 py-2 rounded-lg text-xs font-medium transition-all",
                    filters.minBeds === b
                      ? "bg-amber-500 text-slate-900"
                      : "bg-white/5 border border-white/10 text-white/50 hover:text-white"
                  )}
                >
                  {b === "" ? "Any" : b}
                </button>
              ))}
            </div>
          </div>

          {/* Min Baths */}
          <div>
            <label className="text-white/50 text-xs font-medium block mb-1.5">Min Bathrooms</label>
            <div className="flex gap-1">
              {["", "1", "2", "3", "4+"].map((b) => (
                <button
                  key={b}
                  onClick={() => update("minBaths", b)}
                  className={cn(
                    "flex-1 py-2 rounded-lg text-xs font-medium transition-all",
                    filters.minBaths === b
                      ? "bg-amber-500 text-slate-900"
                      : "bg-white/5 border border-white/10 text-white/50 hover:text-white"
                  )}
                >
                  {b === "" ? "Any" : b}
                </button>
              ))}
            </div>
          </div>

          {/* Furnished */}
          <div>
            <label className="text-white/50 text-xs font-medium block mb-1.5">Furnished</label>
            <div className="flex gap-1">
              {["", "yes", "no"].map((f) => (
                <button
                  key={f}
                  onClick={() => update("furnished", f)}
                  className={cn(
                    "flex-1 py-2 rounded-lg text-xs font-medium transition-all capitalize",
                    filters.furnished === f
                      ? "bg-amber-500 text-slate-900"
                      : "bg-white/5 border border-white/10 text-white/50 hover:text-white"
                  )}
                >
                  {f === "" ? "Any" : f}
                </button>
              ))}
            </div>
          </div>

          {/* Reset */}
          <div className="flex items-end">
            <button
              onClick={reset}
              className="w-full py-2.5 border border-rose-500/30 text-rose-400 hover:bg-rose-500/10 rounded-lg text-sm font-medium transition-all flex items-center justify-center gap-2"
            >
              <X className="w-4 h-4" />
              Clear Filters
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export { DEFAULT_FILTERS };
