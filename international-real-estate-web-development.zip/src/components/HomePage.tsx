"use client";

import Link from "next/link";
import { useState, useEffect, useRef } from "react";
import {
  ArrowRight,
  Play,
  Building2,
  TrendingUp,
  Users,
  Award,
  CheckCircle,
  ChevronLeft,
  ChevronRight,
  Star,
  Quote,
} from "lucide-react";
import { ParticleCanvas, GradientOrbs, ScrollReveal } from "./AnimatedBackground";
import { PropertyCard } from "./PropertyCard";
import { AgentCard } from "./AgentCard";
import { useCurrency } from "./CurrencyContext";
import { PROPERTIES, AGENTS, TESTIMONIALS, SERVICES } from "@/lib/mock-data";

// ── Stat Counter ─────────────────────────────────────────────────────────────
function useCountUp(target: number, duration = 2000) {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLDivElement>(null);
  const started = useRef(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting && !started.current) {
        started.current = true;
        const start = performance.now();
        const step = (ts: number) => {
          const progress = Math.min((ts - start) / duration, 1);
          setCount(Math.floor(progress * target));
          if (progress < 1) requestAnimationFrame(step);
          else setCount(target);
        };
        requestAnimationFrame(step);
        observer.unobserve(el);
      }
    }, { threshold: 0.5 });
    observer.observe(el);
    return () => observer.disconnect();
  }, [target, duration]);

  return { count, ref };
}

function StatCard({ value, suffix, label, icon: Icon }: {
  value: number; suffix: string; label: string; icon: React.ElementType;
}) {
  const { count, ref } = useCountUp(value);
  return (
    <div ref={ref} className="text-center group">
      <div className="w-14 h-14 mx-auto mb-4 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center group-hover:bg-amber-500/20 transition-colors">
        <Icon className="w-6 h-6 text-amber-400" />
      </div>
      <div className="text-4xl font-bold text-white mb-1">
        {count.toLocaleString()}{suffix}
      </div>
      <div className="text-white/50 text-sm">{label}</div>
    </div>
  );
}

// ── Testimonial Carousel ──────────────────────────────────────────────────────
function TestimonialCarousel() {
  const [idx, setIdx] = useState(0);
  const prev = () => setIdx((i) => (i - 1 + TESTIMONIALS.length) % TESTIMONIALS.length);
  const next = () => setIdx((i) => (i + 1) % TESTIMONIALS.length);
  const t = TESTIMONIALS[idx];

  useEffect(() => {
    const id = setInterval(next, 5000);
    return () => clearInterval(id);
  });

  return (
    <div className="relative max-w-3xl mx-auto">
      <div className="bg-slate-900 rounded-3xl p-8 md:p-10 border border-white/5 shadow-2xl">
        <Quote className="w-10 h-10 text-amber-500/30 mb-6" />
        <p className="text-white/80 text-lg leading-relaxed mb-8 italic">
          &ldquo;{t.quote}&rdquo;
        </p>
        <div className="flex items-center gap-4">
          <img
            src={t.clientPhoto}
            alt={t.clientName}
            className="w-14 h-14 rounded-full object-cover border-2 border-amber-500/30"
          />
          <div>
            <div className="text-white font-bold">{t.clientName}</div>
            <div className="text-white/50 text-sm">{t.clientTitle}</div>
            <div className="flex gap-0.5 mt-1">
              {[...Array(t.rating)].map((_, i) => (
                <Star key={i} className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Controls */}
      <div className="flex items-center justify-center gap-4 mt-6">
        <button onClick={prev} aria-label="Previous testimonial" className="w-10 h-10 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 flex items-center justify-center text-white transition-colors">
          <ChevronLeft className="w-5 h-5" />
        </button>
        <div className="flex gap-2">
          {TESTIMONIALS.map((_, i) => (
            <button key={i} onClick={() => setIdx(i)} aria-label={`Testimonial ${i + 1}`} className={`w-2 h-2 rounded-full transition-all ${i === idx ? "bg-amber-400 w-6" : "bg-white/20"}`} />
          ))}
        </div>
        <button onClick={next} aria-label="Next testimonial" className="w-10 h-10 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 flex items-center justify-center text-white transition-colors">
          <ChevronRight className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
}

// ── Main Home Page ────────────────────────────────────────────────────────────
export function HomePage() {
  const { currency } = useCurrency();
  const featuredProperties = PROPERTIES.filter((p) => p.featured).slice(0, 4);
  const [videoPlaying, setVideoPlaying] = useState(false);

  return (
    <div className="overflow-x-hidden">
      {/* ── HERO ─────────────────────────────────────────────────────────────── */}
      <section
        className="relative min-h-screen flex items-center justify-center overflow-hidden"
        aria-labelledby="hero-heading"
      >
        {/* Background */}
        <div className="absolute inset-0">
          <img
            src="https://images.pexels.com/photos/11596373/pexels-photo-11596373.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1600"
            alt="Luxury real estate Bangladesh skyline"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-slate-950/90 via-slate-950/70 to-slate-950" />
          <div className="absolute inset-0 hero-gradient" />
        </div>

        {/* Particles */}
        <ParticleCanvas />
        <GradientOrbs />

        {/* Content */}
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center pt-24 pb-16">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-amber-500/10 border border-amber-500/30 rounded-full text-amber-400 text-sm font-medium mb-8 animate-fade-in-up">
            <span className="w-2 h-2 bg-amber-400 rounded-full animate-pulse" />
            Bangladesh&apos;s Most Trusted Real Estate Developer
          </div>

          <h1
            id="hero-heading"
            className="text-4xl sm:text-6xl lg:text-7xl font-bold text-white mb-6 leading-[1.1] animate-fade-in-up"
            style={{ animationDelay: "0.1s" }}
          >
            Build Your
            <span className="gradient-text block">Dream in Bangladesh</span>
          </h1>

          <p
            className="text-white/60 text-lg sm:text-xl max-w-2xl mx-auto mb-10 leading-relaxed animate-fade-in-up"
            style={{ animationDelay: "0.2s" }}
          >
            Premium apartments, villas, and commercial spaces across Rangpur, Dhaka,
            Chittagong and beyond. Quality-built, on-time delivered.
          </p>

          {/* CTA Buttons */}
          <div
            className="flex flex-col sm:flex-row gap-4 justify-center mb-16 animate-fade-in-up"
            style={{ animationDelay: "0.3s" }}
          >
            <Link
              href="/properties"
              className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-amber-500 hover:bg-amber-400 text-slate-900 font-bold rounded-2xl text-base transition-all shadow-lg shadow-amber-500/30 hover:shadow-amber-500/50 hover:-translate-y-0.5"
            >
              Browse Properties
              <ArrowRight className="w-5 h-5" />
            </Link>
            <button
              onClick={() => setVideoPlaying(true)}
              className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-white/5 hover:bg-white/10 border border-white/20 text-white font-semibold rounded-2xl text-base transition-all backdrop-blur-sm hover:-translate-y-0.5"
            >
              <Play className="w-5 h-5 text-amber-400" />
              Watch Our Story
            </button>
            <Link
              href="/contact"
              className="inline-flex items-center justify-center gap-2 px-8 py-4 border border-amber-500/30 text-amber-400 hover:bg-amber-500/10 font-semibold rounded-2xl text-base transition-all hover:-translate-y-0.5"
            >
              Free Consultation
            </Link>
          </div>

          {/* Quick Stats Row */}
          <div
            className="grid grid-cols-3 gap-4 max-w-lg mx-auto animate-fade-in-up"
            style={{ animationDelay: "0.4s" }}
          >
            {[
              { value: "500+", label: "Projects Delivered" },
              { value: "12+", label: "Years Experience" },
              { value: "98%", label: "Client Satisfaction" },
            ].map((s) => (
              <div key={s.label} className="glass rounded-xl p-4">
                <div className="text-amber-400 font-bold text-xl">{s.value}</div>
                <div className="text-white/40 text-xs mt-1">{s.label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-white/30 animate-bounce">
          <span className="text-xs tracking-widest uppercase">Scroll</span>
          <div className="w-px h-8 bg-gradient-to-b from-white/20 to-transparent" />
        </div>
      </section>

      {/* Video Modal */}
      {videoPlaying && (
        <div
          className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-4"
          onClick={() => setVideoPlaying(false)}
          role="dialog"
          aria-modal="true"
          aria-label="Company video"
        >
          <div className="relative w-full max-w-4xl aspect-video bg-slate-900 rounded-2xl flex items-center justify-center">
            <p className="text-white/40 text-center p-8">
              Video player would be embedded here (YouTube / Vimeo integration).<br />
              <button className="mt-4 text-amber-400 underline" onClick={() => setVideoPlaying(false)}>Close</button>
            </p>
          </div>
        </div>
      )}

      {/* ── STATS ────────────────────────────────────────────────────────────── */}
      <section className="py-20 border-y border-white/5" aria-labelledby="stats-heading">
        <h2 id="stats-heading" className="sr-only">Company Statistics</h2>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-10">
            <StatCard value={500} suffix="+" label="Projects Delivered" icon={Building2} />
            <StatCard value={12} suffix="+" label="Years in Market" icon={TrendingUp} />
            <StatCard value={2400} suffix="+" label="Happy Families" icon={Users} />
            <StatCard value={18} suffix="" label="Industry Awards" icon={Award} />
          </div>
        </div>
      </section>

      {/* ── FEATURED PROPERTIES ───────────────────────────────────────────────── */}
      <section className="section-pad" aria-labelledby="featured-heading">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollReveal>
            <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-12">
              <div>
                <span className="text-amber-400 text-sm font-semibold uppercase tracking-widest mb-2 block">
                  Featured Listings
                </span>
                <h2 id="featured-heading" className="text-3xl sm:text-4xl font-bold text-white">
                  Handpicked Properties
                </h2>
                <p className="text-white/50 mt-2 max-w-md">
                  Our most sought-after listings — premium quality, prime locations.
                </p>
              </div>
              <Link
                href="/properties"
                className="flex items-center gap-2 text-amber-400 hover:text-amber-300 font-semibold text-sm transition-colors shrink-0"
              >
                View All Properties
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </ScrollReveal>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredProperties.map((p, i) => (
              <ScrollReveal key={p.id} delay={i * 0.1}>
                <PropertyCard property={p} currency={currency} />
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>

      {/* ── SERVICES ─────────────────────────────────────────────────────────── */}
      <section className="section-pad bg-slate-900/50 border-y border-white/5 relative overflow-hidden" aria-labelledby="services-heading">
        <GradientOrbs />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollReveal className="text-center mb-16">
            <span className="text-amber-400 text-sm font-semibold uppercase tracking-widest mb-2 block">
              What We Offer
            </span>
            <h2 id="services-heading" className="text-3xl sm:text-4xl font-bold text-white">
              Comprehensive Real Estate Services
            </h2>
            <p className="text-white/50 mt-3 max-w-xl mx-auto">
              From land acquisition to handover — we manage every stage with expertise and care.
            </p>
          </ScrollReveal>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {SERVICES.map((svc, i) => (
              <ScrollReveal key={svc.title} delay={i * 0.08}>
                <div className="group p-6 bg-slate-900 rounded-2xl border border-white/5 hover:border-amber-500/20 transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-amber-500/5">
                  <div className="text-4xl mb-4">{svc.icon}</div>
                  <h3 className="text-white font-bold text-lg mb-2 group-hover:text-amber-400 transition-colors">
                    {svc.title}
                  </h3>
                  <p className="text-white/50 text-sm leading-relaxed">{svc.description}</p>
                </div>
              </ScrollReveal>
            ))}
          </div>

          <ScrollReveal className="text-center mt-10">
            <Link
              href="/services"
              className="inline-flex items-center gap-2 px-8 py-3 bg-amber-500 hover:bg-amber-400 text-slate-900 font-bold rounded-xl transition-all shadow-lg shadow-amber-500/20"
            >
              Explore All Services
              <ArrowRight className="w-4 h-4" />
            </Link>
          </ScrollReveal>
        </div>
      </section>

      {/* ── WHY CHOOSE US ─────────────────────────────────────────────────────── */}
      <section className="section-pad" aria-labelledby="why-heading">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            {/* Image collage */}
            <ScrollReveal className="relative h-[500px] hidden lg:block">
              <img
                src="https://images.pexels.com/photos/18340726/pexels-photo-18340726.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=800"
                alt="Modern RDAL residential building"
                className="absolute top-0 left-0 w-3/4 h-3/4 object-cover rounded-3xl"
              />
              <img
                src="https://images.pexels.com/photos/6957083/pexels-photo-6957083.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=400&w=600"
                alt="Premium interior design"
                className="absolute bottom-0 right-0 w-2/3 h-2/3 object-cover rounded-3xl border-4 border-slate-950"
              />
              {/* Floating badge */}
              <div className="absolute top-1/2 right-0 -translate-y-1/2 bg-amber-500 rounded-2xl p-4 shadow-2xl shadow-amber-500/30">
                <div className="text-slate-900 font-bold text-2xl">14+</div>
                <div className="text-slate-900/70 text-xs font-medium">Years Building Dreams</div>
              </div>
            </ScrollReveal>

            {/* Text */}
            <ScrollReveal delay={0.2}>
              <span className="text-amber-400 text-sm font-semibold uppercase tracking-widest mb-2 block">
                Why Choose RDAL
              </span>
              <h2 id="why-heading" className="text-3xl sm:text-4xl font-bold text-white mb-6">
                Trusted by 2,400+ Families Across Bangladesh
              </h2>
              <p className="text-white/60 leading-relaxed mb-8">
                Since 2010, Rangpur Architectural Design Ltd. has been at the forefront of Bangladesh&apos;s
                real estate sector — delivering projects that blend architectural excellence, structural
                safety, and unmatched after-sales service.
              </p>

              <ul className="space-y-4 mb-8">
                {[
                  "On-time project delivery — guaranteed in writing",
                  "RAJUK-compliant construction with licensed architects",
                  "Transparent pricing — no hidden fees",
                  "Dedicated NRB (Non-Resident Bangladeshi) investment desk",
                  "15-year structural warranty on all projects",
                  "Award-winning in-house design team",
                ].map((point) => (
                  <li key={point} className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                    <span className="text-white/70 text-sm leading-relaxed">{point}</span>
                  </li>
                ))}
              </ul>

              <div className="flex flex-col sm:flex-row gap-3">
                <Link
                  href="/about"
                  className="inline-flex items-center justify-center gap-2 px-6 py-3 bg-amber-500 hover:bg-amber-400 text-slate-900 font-bold rounded-xl transition-all"
                >
                  Our Story
                  <ArrowRight className="w-4 h-4" />
                </Link>
                <Link
                  href="/contact"
                  className="inline-flex items-center justify-center gap-2 px-6 py-3 border border-amber-500/30 text-amber-400 hover:bg-amber-500/10 font-semibold rounded-xl transition-all"
                >
                  Free Consultation
                </Link>
              </div>
            </ScrollReveal>
          </div>
        </div>
      </section>

      {/* ── AGENTS ───────────────────────────────────────────────────────────── */}
      <section className="section-pad bg-slate-900/50 border-y border-white/5" aria-labelledby="agents-heading">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollReveal className="text-center mb-16">
            <span className="text-amber-400 text-sm font-semibold uppercase tracking-widest mb-2 block">
              Meet the Team
            </span>
            <h2 id="agents-heading" className="text-3xl sm:text-4xl font-bold text-white">
              Expert Property Consultants
            </h2>
            <p className="text-white/50 mt-3 max-w-xl mx-auto">
              Our multi-lingual team is ready to help you find, invest, or develop property anywhere in Bangladesh.
            </p>
          </ScrollReveal>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {AGENTS.map((agent, i) => (
              <ScrollReveal key={agent.id} delay={i * 0.1}>
                <AgentCard agent={agent} />
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>

      {/* ── TESTIMONIALS ─────────────────────────────────────────────────────── */}
      <section className="section-pad relative overflow-hidden" aria-labelledby="testimonials-heading">
        <GradientOrbs />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollReveal className="text-center mb-16">
            <span className="text-amber-400 text-sm font-semibold uppercase tracking-widest mb-2 block">
              Client Stories
            </span>
            <h2 id="testimonials-heading" className="text-3xl sm:text-4xl font-bold text-white">
              What Our Clients Say
            </h2>
          </ScrollReveal>
          <ScrollReveal delay={0.1}>
            <TestimonialCarousel />
          </ScrollReveal>
        </div>
      </section>

      {/* ── CTA BAND ─────────────────────────────────────────────────────────── */}
      <section
        className="relative py-24 overflow-hidden"
        aria-labelledby="cta-heading"
      >
        <div className="absolute inset-0 bg-gradient-to-r from-amber-600 to-amber-500" />
        <div className="absolute inset-0 opacity-20">
          <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiMwMDAiIGZpbGwtb3BhY2l0eT0iMC4xNSI+PHBhdGggZD0iTTM2IDM0di00aC0ydjRoLTR2Mmg0djRoMnYtNGg0di0yaC00em0wLTMwVjBoLTJ2NGgtNHYyaDR2NGgyVjZoNFY0aC00ek02IDM0di00SDR2NEgwdjJoNHY0aDJ2LTRoNHYtMkg2ek02IDRWMEg0djRIMHYyaDR2NGgyVjZoNFY0SDZ6Ii8+PC9nPjwvZz48L3N2Zz4=')]" />
        </div>

        <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 id="cta-heading" className="text-3xl sm:text-5xl font-bold text-slate-900 mb-4">
            Ready to Find Your Perfect Property?
          </h2>
          <p className="text-slate-900/70 text-lg mb-10 max-w-xl mx-auto">
            Join 2,400+ families who trusted RDAL to deliver their dream home — on time, every time.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              href="/properties"
              className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-2xl text-base transition-all shadow-xl"
            >
              Browse All Properties
              <ArrowRight className="w-5 h-5" />
            </Link>
            <Link
              href="/contact"
              className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-white/20 hover:bg-white/30 backdrop-blur text-slate-900 font-bold rounded-2xl text-base transition-all border border-white/30"
            >
              Talk to an Agent
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
