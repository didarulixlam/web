"use client";

import Link from "next/link";
import { MapPin, Bed, Bath, Maximize, Heart, Eye, Star } from "lucide-react";
import { cn, formatPrice } from "@/lib/utils";
import type { Property } from "@/lib/mock-data";
import { useState } from "react";

const TYPE_COLORS: Record<string, string> = {
  apartment: "bg-blue-500/20 text-blue-300 border-blue-500/30",
  villa: "bg-purple-500/20 text-purple-300 border-purple-500/30",
  commercial: "bg-green-500/20 text-green-300 border-green-500/30",
  land: "bg-orange-500/20 text-orange-300 border-orange-500/30",
  duplex: "bg-pink-500/20 text-pink-300 border-pink-500/30",
};

export function PropertyCard({
  property,
  currency = "USD",
  className,
}: {
  property: Property;
  currency?: string;
  className?: string;
}) {
  const [liked, setLiked] = useState(false);
  const [imgErr, setImgErr] = useState(false);

  const displayPrice =
    currency === "BDT"
      ? formatPrice(property.priceBDT, "BDT")
      : currency === "GBP"
      ? formatPrice(property.priceUSD * 0.79, "GBP")
      : currency === "EUR"
      ? formatPrice(property.priceUSD * 0.92, "EUR")
      : formatPrice(property.priceUSD, "USD");

  const perLabel = property.listingType === "rent" ? "/mo" : "";

  return (
    <article
      className={cn(
        "group relative bg-slate-900 rounded-2xl overflow-hidden border border-white/5 hover:border-amber-500/30 transition-all duration-300 hover:-translate-y-1 hover:shadow-2xl hover:shadow-amber-500/10",
        className
      )}
    >
      {/* Image */}
      <div className="relative h-52 overflow-hidden">
        <img
          src={imgErr ? "https://images.pexels.com/photos/18340726/pexels-photo-18340726.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=400&w=800" : (property.images[0] ?? "")}
          alt={property.title}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          onError={() => setImgErr(true)}
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-transparent to-transparent" />

        {/* Badges */}
        <div className="absolute top-3 left-3 flex gap-2 flex-wrap">
          <span
            className={cn(
              "px-2 py-0.5 text-xs font-semibold rounded-full border capitalize",
              TYPE_COLORS[property.type] ?? "bg-slate-500/20 text-slate-300"
            )}
          >
            {property.type}
          </span>
          <span
            className={cn(
              "px-2 py-0.5 text-xs font-semibold rounded-full",
              property.listingType === "rent"
                ? "bg-teal-500/20 text-teal-300 border border-teal-500/30"
                : "bg-amber-500/20 text-amber-300 border border-amber-500/30"
            )}
          >
            For {property.listingType === "rent" ? "Rent" : "Sale"}
          </span>
          {property.featured && (
            <span className="px-2 py-0.5 text-xs font-semibold rounded-full bg-amber-500 text-slate-900 flex items-center gap-1">
              <Star className="w-3 h-3" />
              Featured
            </span>
          )}
        </div>

        {/* Like */}
        <button
          onClick={(e) => { e.preventDefault(); setLiked(!liked); }}
          aria-label={liked ? "Remove from favourites" : "Add to favourites"}
          className="absolute top-3 right-3 w-8 h-8 rounded-full bg-black/40 backdrop-blur-sm flex items-center justify-center hover:bg-black/60 transition-colors"
        >
          <Heart className={cn("w-4 h-4 transition-colors", liked ? "fill-rose-500 text-rose-500" : "text-white")} />
        </button>

        {/* Views */}
        <div className="absolute bottom-3 right-3 flex items-center gap-1 text-white/60 text-xs">
          <Eye className="w-3 h-3" />
          {property.views.toLocaleString()}
        </div>
      </div>

      {/* Body */}
      <div className="p-5">
        <div className="flex items-start justify-between gap-2 mb-2">
          <h3 className="font-bold text-white text-base leading-snug line-clamp-2 group-hover:text-amber-400 transition-colors">
            {property.title}
          </h3>
        </div>

        <div className="flex items-center gap-1.5 text-white/50 text-xs mb-4">
          <MapPin className="w-3 h-3 text-amber-400 shrink-0" />
          <span className="truncate">{property.city}, {property.district}</span>
        </div>

        {/* Stats */}
        {property.type !== "land" && (
          <div className="flex items-center gap-4 mb-4">
            {property.bedrooms > 0 && (
              <div className="flex items-center gap-1.5 text-white/60 text-xs">
                <Bed className="w-3.5 h-3.5 text-amber-400/70" />
                <span>{property.bedrooms} Bed{property.bedrooms !== 1 ? "s" : ""}</span>
              </div>
            )}
            {property.bathrooms > 0 && (
              <div className="flex items-center gap-1.5 text-white/60 text-xs">
                <Bath className="w-3.5 h-3.5 text-amber-400/70" />
                <span>{property.bathrooms} Bath{property.bathrooms !== 1 ? "s" : ""}</span>
              </div>
            )}
            <div className="flex items-center gap-1.5 text-white/60 text-xs">
              <Maximize className="w-3.5 h-3.5 text-amber-400/70" />
              <span>{property.areaSqft?.toLocaleString()} sqft</span>
            </div>
          </div>
        )}

        {/* Price + CTA */}
        <div className="flex items-center justify-between pt-4 border-t border-white/5">
          <div>
            <div className="text-amber-400 font-bold text-lg leading-none">
              {displayPrice}
              {perLabel && <span className="text-xs text-white/40 font-normal ml-1">{perLabel}</span>}
            </div>
            {property.areaSqft && property.type !== "land" && (
              <div className="text-white/30 text-xs mt-0.5">
                {formatPrice(property.priceUSD / property.areaSqft, "USD")}/sqft
              </div>
            )}
          </div>
          <Link
            href={`/properties/${property.slug}`}
            className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-900 font-semibold text-xs rounded-lg transition-colors"
          >
            View Details
          </Link>
        </div>
      </div>
    </article>
  );
}
