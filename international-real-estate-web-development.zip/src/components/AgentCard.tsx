import { Phone, Mail, Star, Award } from "lucide-react";
import type { Agent } from "@/lib/mock-data";
import Link from "next/link";

export function AgentCard({ agent, compact = false }: { agent: Agent; compact?: boolean }) {
  return (
    <article className="bg-slate-900 rounded-2xl border border-white/5 hover:border-amber-500/20 overflow-hidden transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-amber-500/5">
      <div className={compact ? "p-5 flex gap-4 items-start" : "p-6"}>
        {/* Avatar */}
        <div className={compact ? "shrink-0" : "flex items-center gap-4 mb-5"}>
          <div className={`relative rounded-xl overflow-hidden ${compact ? "w-14 h-14" : "w-16 h-16"}`}>
            <img
              src={agent.photoUrl}
              alt={agent.name}
              className="w-full h-full object-cover"
              loading="lazy"
            />
          </div>
          {!compact && (
            <div className="flex-1 min-w-0">
              <h3 className="text-white font-bold text-base truncate">{agent.name}</h3>
              <p className="text-amber-400/80 text-sm">{agent.title}</p>
            </div>
          )}
        </div>

        <div className={compact ? "flex-1 min-w-0" : ""}>
          {compact && (
            <>
              <h3 className="text-white font-bold text-sm">{agent.name}</h3>
              <p className="text-amber-400/70 text-xs">{agent.title}</p>
            </>
          )}

          {!compact && (
            <p className="text-white/50 text-sm leading-relaxed mb-5 line-clamp-3">
              {agent.bio}
            </p>
          )}

          {/* Stats */}
          <div className={`flex gap-4 ${compact ? "mt-2" : "mb-5"}`}>
            <div className="flex items-center gap-1.5">
              <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
              <span className="text-white text-sm font-semibold">{agent.rating}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Award className="w-3.5 h-3.5 text-amber-400" />
              <span className="text-white/60 text-xs">{agent.dealsClosed} deals</span>
            </div>
          </div>

          {!compact && (
            <>
              {/* Languages */}
              <div className="flex flex-wrap gap-1.5 mb-5">
                {agent.languages.map((lang) => (
                  <span
                    key={lang}
                    className="px-2 py-0.5 bg-white/5 border border-white/10 rounded-full text-white/50 text-xs"
                  >
                    {lang}
                  </span>
                ))}
              </div>

              {/* Contact */}
              <div className="flex gap-2">
                <a
                  href={`tel:${agent.phone}`}
                  className="flex-1 flex items-center justify-center gap-2 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-900 font-semibold text-sm rounded-xl transition-colors"
                  aria-label={`Call ${agent.name}`}
                >
                  <Phone className="w-4 h-4" />
                  Call
                </a>
                <a
                  href={`mailto:${agent.email}`}
                  className="flex-1 flex items-center justify-center gap-2 py-2.5 bg-white/5 hover:bg-white/10 border border-white/10 text-white font-medium text-sm rounded-xl transition-colors"
                  aria-label={`Email ${agent.name}`}
                >
                  <Mail className="w-4 h-4" />
                  Email
                </a>
              </div>
            </>
          )}

          {compact && (
            <div className="flex gap-2 mt-3">
              <a
                href={`tel:${agent.phone}`}
                className="p-2 bg-amber-500/20 hover:bg-amber-500/30 text-amber-400 rounded-lg transition-colors"
                aria-label={`Call ${agent.name}`}
              >
                <Phone className="w-3.5 h-3.5" />
              </a>
              <a
                href={`mailto:${agent.email}`}
                className="p-2 bg-white/5 hover:bg-white/10 border border-white/10 text-white/60 rounded-lg transition-colors"
                aria-label={`Email ${agent.name}`}
              >
                <Mail className="w-3.5 h-3.5" />
              </a>
            </div>
          )}
        </div>
      </div>

      {!compact && (
        <div className="px-6 py-3 border-t border-white/5 bg-white/2">
          <Link
            href="/agents"
            className="text-amber-400/70 hover:text-amber-400 text-xs font-medium transition-colors"
          >
            View full profile →
          </Link>
        </div>
      )}
    </article>
  );
}
