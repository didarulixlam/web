"use client";

import { MapPin, ExternalLink } from "lucide-react";

interface MapStubProps {
  latitude: number;
  longitude: number;
  title: string;
  address: string;
}

export function MapStub({ latitude, longitude, title, address }: MapStubProps) {
  const mapsUrl = `https://www.google.com/maps?q=${latitude},${longitude}`;
  const embedUrl = `https://www.openstreetmap.org/export/embed.html?bbox=${longitude - 0.01}%2C${latitude - 0.01}%2C${longitude + 0.01}%2C${latitude + 0.01}&layer=mapnik&marker=${latitude}%2C${longitude}`;

  return (
    <div className="relative rounded-2xl overflow-hidden border border-white/10 bg-slate-900">
      {/* Map embed via OpenStreetMap (no API key needed) */}
      <iframe
        title={`Map showing location of ${title}`}
        src={embedUrl}
        className="w-full h-72 border-0"
        loading="lazy"
        aria-label={`Map for ${address}`}
      />
      {/* Overlay bar */}
      <div className="absolute bottom-0 left-0 right-0 bg-slate-900/90 backdrop-blur-sm px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2 min-w-0">
          <MapPin className="w-4 h-4 text-amber-400 shrink-0" />
          <span className="text-white/70 text-sm truncate">{address}</span>
        </div>
        <a
          href={mapsUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="ml-3 flex items-center gap-1.5 px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-900 font-semibold text-xs rounded-lg transition-colors shrink-0"
        >
          Open in Maps
          <ExternalLink className="w-3 h-3" />
        </a>
      </div>
    </div>
  );
}
